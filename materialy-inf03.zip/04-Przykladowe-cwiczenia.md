# INF.03 Ćwiczenia z kodem

Poniżej jest po jednym przykładzie z każdej rodziny. Kolejne warianty odtwarza plik cwiczenia.mjs. Laboratorium w przyszłej stronie użyje jego poleceń, danych i kryteriów.

## Wybierz rekordy z warunkiem

**SQL** · Wypożyczalnia rowerów · Poziom 1 · `sql-filtr/wypozyczalnia/01`

Zwróć nazwa i cena dla rekordów z aktywny = 0 oraz cena ≥ 17. Posortuj według id rosnąco.

**Dane startowe**

```sql
CREATE TABLE typy (id INT PRIMARY KEY, nazwa VARCHAR(80) NOT NULL);
CREATE TABLE rowery (id INT PRIMARY KEY, nazwa VARCHAR(80) NOT NULL, cena INT NOT NULL, grupa_id INT NOT NULL, aktywny INT NOT NULL, FOREIGN KEY (grupa_id) REFERENCES typy(id));
INSERT INTO typy VALUES (1, 'Podstawowa'), (2, 'Dodatkowa'), (3, 'Sezonowa'), (4, 'Pusta');
INSERT INTO rowery VALUES (1, 'rower Alfa 1', 17, 1, 0), (2, 'rower Beta 1', 27, 2, 1), (3, 'rower Gamma 1', 37, 3, 0), (4, 'rower Delta 1', 21, 1, 1), (5, 'rower Epsilon 1', 31, 2, 0), (6, 'rower Zeta 1', 41, 3, 1), (7, 'rower Eta 1', 25, 1, 0), (8, 'rower Iota 1', 35, 2, 1);
```

**Kod lub materiał startowy**

```sql
SELECT ... FROM rowery
WHERE ...;
```

**Podpowiedź**

Połącz warunki operatorem AND. Uwzględnij wartość równą progowi.

**Co powinno wyjść**

```json
[
  [
    "rower Alfa 1",
    17
  ],
  [
    "rower Gamma 1",
    37
  ],
  [
    "rower Epsilon 1",
    31
  ],
  [
    "rower Eta 1",
    25
  ]
]
```

**Rozwiązanie**

```sql
SELECT nazwa, cena FROM rowery WHERE aktywny = 0 AND cena >= 17 ORDER BY id;
```

## Posortuj i ogranicz wynik

**SQL** · Biblioteka · Poziom 1 · `sql-top/biblioteka/02`

Zwróć 3 rekordy, kolumny id i cena. Sortuj po cenie malejąco, przy remisie po id rosnąco.

**Dane startowe**

```sql
CREATE TABLE dzialy (id INT PRIMARY KEY, nazwa VARCHAR(80) NOT NULL);
CREATE TABLE ksiazki (id INT PRIMARY KEY, nazwa VARCHAR(80) NOT NULL, cena INT NOT NULL, grupa_id INT NOT NULL, aktywny INT NOT NULL, FOREIGN KEY (grupa_id) REFERENCES dzialy(id));
INSERT INTO dzialy VALUES (1, 'Podstawowa'), (2, 'Dodatkowa'), (3, 'Sezonowa'), (4, 'Pusta');
INSERT INTO ksiazki VALUES (1, 'książka Alfa 2', 36, 2, 1), (2, 'książka Beta 2', 46, 3, 1), (3, 'książka Gamma 2', 56, 1, 1), (4, 'książka Delta 2', 40, 2, 1), (5, 'książka Epsilon 2', 50, 3, 1), (6, 'książka Zeta 2', 34, 1, 1), (7, 'książka Eta 2', 44, 2, 1), (8, 'książka Iota 2', 54, 3, 1);
```

**Kod lub materiał startowy**

```sql
SELECT id, cena FROM ksiazki;
```

**Podpowiedź**

Przed LIMIT użyj ORDER BY z dwiema kolumnami.

**Co powinno wyjść**

```json
[
  [
    3,
    56
  ],
  [
    8,
    54
  ],
  [
    5,
    50
  ]
]
```

**Rozwiązanie**

```sql
SELECT id, cena FROM ksiazki ORDER BY cena DESC, id ASC LIMIT 3;
```

## Odczytaj nazwę kategorii

**SQL** · Serwis komputerowy · Poziom 2 · `sql-join/serwis/03`

Zwróć nazwę pozycji i nazwę grupy dla rekordów z aktywny = 0. Połącz obie tabele i sortuj po id pozycji.

**Dane startowe**

```sql
CREATE TABLE rodzaje (id INT PRIMARY KEY, nazwa VARCHAR(80) NOT NULL);
CREATE TABLE uslugi (id INT PRIMARY KEY, nazwa VARCHAR(80) NOT NULL, cena INT NOT NULL, grupa_id INT NOT NULL, aktywny INT NOT NULL, FOREIGN KEY (grupa_id) REFERENCES rodzaje(id));
INSERT INTO rodzaje VALUES (1, 'Podstawowa'), (2, 'Dodatkowa'), (3, 'Sezonowa'), (4, 'Pusta');
INSERT INTO uslugi VALUES (1, 'usługa Alfa 3', 55, 3, 1), (2, 'usługa Beta 3', 65, 1, 0), (3, 'usługa Gamma 3', 75, 2, 1), (4, 'usługa Delta 3', 59, 3, 0), (5, 'usługa Epsilon 3', 69, 1, 1), (6, 'usługa Zeta 3', 53, 2, 0), (7, 'usługa Eta 3', 63, 3, 1), (8, 'usługa Iota 3', 73, 1, 0);
```

**Kod lub materiał startowy**

```sql
SELECT p.nazwa, g.nazwa FROM uslugi AS p
-- uzupełnij złączenie i filtr
```

**Podpowiedź**

Połącz grupa_id pozycji z id w słowniku grup.

**Co powinno wyjść**

```json
[
  [
    "usługa Beta 3",
    "Podstawowa"
  ],
  [
    "usługa Delta 3",
    "Sezonowa"
  ],
  [
    "usługa Zeta 3",
    "Dodatkowa"
  ],
  [
    "usługa Iota 3",
    "Podstawowa"
  ]
]
```

**Rozwiązanie**

```sql
SELECT p.nazwa, g.nazwa FROM uslugi AS p INNER JOIN rodzaje AS g ON p.grupa_id = g.id WHERE p.aktywny = 0 ORDER BY p.id;
```

## Zlicz również puste grupy

**SQL** · Kino · Poziom 2 · `sql-grupy/kino/04`

Dla każdej grupy zwróć jej nazwę i liczbę pozycji z ceną co najmniej 74. Zachowaj grupy o wyniku 0. Sortuj po id grupy.

**Dane startowe**

```sql
CREATE TABLE gatunki (id INT PRIMARY KEY, nazwa VARCHAR(80) NOT NULL);
CREATE TABLE seanse (id INT PRIMARY KEY, nazwa VARCHAR(80) NOT NULL, cena INT NOT NULL, grupa_id INT NOT NULL, aktywny INT NOT NULL, FOREIGN KEY (grupa_id) REFERENCES gatunki(id));
INSERT INTO gatunki VALUES (1, 'Podstawowa'), (2, 'Dodatkowa'), (3, 'Sezonowa'), (4, 'Pusta');
INSERT INTO seanse VALUES (1, 'seans Alfa 4', 74, 1, 0), (2, 'seans Beta 4', 84, 2, 1), (3, 'seans Gamma 4', 68, 3, 0), (4, 'seans Delta 4', 78, 1, 1), (5, 'seans Epsilon 4', 88, 2, 0), (6, 'seans Zeta 4', 72, 3, 1), (7, 'seans Eta 4', 82, 1, 0), (8, 'seans Iota 4', 92, 2, 1);
```

**Kod lub materiał startowy**

```sql
SELECT g.nazwa, COUNT(...) FROM gatunki AS g
-- dodaj złączenie, grupowanie i kolejność
```

**Podpowiedź**

Zastosuj LEFT JOIN, warunek cenowy w ON i COUNT(p.id).

**Co powinno wyjść**

```json
[
  [
    "Podstawowa",
    3
  ],
  [
    "Dodatkowa",
    3
  ],
  [
    "Sezonowa",
    0
  ],
  [
    "Pusta",
    0
  ]
]
```

**Rozwiązanie**

```sql
SELECT g.nazwa, COUNT(p.id) AS liczba FROM gatunki AS g LEFT JOIN seanse AS p ON p.grupa_id = g.id AND p.cena >= 74 GROUP BY g.id, g.nazwa ORDER BY g.id;
```

## Zmień cenę jednego rekordu

**SQL** · Muzeum · Poziom 2 · `sql-update/muzeum/05`

Ustaw cenę 133 rekordowi o id = 5. Pozostałe rekordy i ich wartości mają zostać zachowane.

**Dane startowe**

```sql
CREATE TABLE sale (id INT PRIMARY KEY, nazwa VARCHAR(80) NOT NULL);
CREATE TABLE wystawy (id INT PRIMARY KEY, nazwa VARCHAR(80) NOT NULL, cena INT NOT NULL, grupa_id INT NOT NULL, aktywny INT NOT NULL, FOREIGN KEY (grupa_id) REFERENCES sale(id));
INSERT INTO sale VALUES (1, 'Podstawowa'), (2, 'Dodatkowa'), (3, 'Sezonowa'), (4, 'Pusta');
INSERT INTO wystawy VALUES (1, 'wystawa Alfa 5', 93, 2, 1), (2, 'wystawa Beta 5', 103, 3, 1), (3, 'wystawa Gamma 5', 87, 1, 1), (4, 'wystawa Delta 5', 97, 2, 1), (5, 'wystawa Epsilon 5', 107, 3, 1), (6, 'wystawa Zeta 5', 91, 1, 1), (7, 'wystawa Eta 5', 101, 2, 1), (8, 'wystawa Iota 5', 85, 3, 1);
```

**Kod lub materiał startowy**

```sql
UPDATE wystawy SET ... WHERE ...;
```

**Podpowiedź**

Porównaj wszystkie wiersze. Użyj id w WHERE.

**Co powinno wyjść**

```json
[
  [
    1,
    "wystawa Alfa 5",
    93,
    2,
    1
  ],
  [
    2,
    "wystawa Beta 5",
    103,
    3,
    1
  ],
  [
    3,
    "wystawa Gamma 5",
    87,
    1,
    1
  ],
  [
    4,
    "wystawa Delta 5",
    97,
    2,
    1
  ],
  [
    5,
    "wystawa Epsilon 5",
    133,
    3,
    1
  ],
  [
    6,
    "wystawa Zeta 5",
    91,
    1,
    1
  ],
  [
    7,
    "wystawa Eta 5",
    101,
    2,
    1
  ],
  [
    8,
    "wystawa Iota 5",
    85,
    3,
    1
  ]
]
```

**Rozwiązanie**

```sql
UPDATE wystawy SET cena = 133 WHERE id = 5;
```

## Wybierz grupy według liczebności

**SQL** · Kawiarnia · Poziom 3 · `sql-having/kawiarnia/06`

Pokaż grupa_id i liczbę pozycji z ceną ≥ 112. Wyświetl grupy z co najmniej 2 takimi pozycjami. Sortuj według grupa_id.

**Dane startowe**

```sql
CREATE TABLE kategorie (id INT PRIMARY KEY, nazwa VARCHAR(80) NOT NULL);
CREATE TABLE desery (id INT PRIMARY KEY, nazwa VARCHAR(80) NOT NULL, cena INT NOT NULL, grupa_id INT NOT NULL, aktywny INT NOT NULL, FOREIGN KEY (grupa_id) REFERENCES kategorie(id));
INSERT INTO kategorie VALUES (1, 'Podstawowa'), (2, 'Dodatkowa'), (3, 'Sezonowa'), (4, 'Pusta');
INSERT INTO desery VALUES (1, 'deser Alfa 6', 112, 3, 1), (2, 'deser Beta 6', 122, 1, 0), (3, 'deser Gamma 6', 106, 2, 1), (4, 'deser Delta 6', 116, 3, 0), (5, 'deser Epsilon 6', 126, 1, 1), (6, 'deser Zeta 6', 110, 2, 0), (7, 'deser Eta 6', 120, 3, 1), (8, 'deser Iota 6', 104, 1, 0);
```

**Kod lub materiał startowy**

```sql
SELECT grupa_id, COUNT(*) FROM desery ...;
```

**Podpowiedź**

Najpierw filtr ceny w WHERE, potem filtr liczby w HAVING.

**Co powinno wyjść**

```json
[
  [
    1,
    2
  ],
  [
    3,
    3
  ]
]
```

**Rozwiązanie**

```sql
SELECT grupa_id, COUNT(*) AS liczba FROM desery WHERE cena >= 112 GROUP BY grupa_id HAVING COUNT(*) >= 2 ORDER BY grupa_id;
```

## Dodaj rekord przypisany do grupy

**SQL** · Kursy zawodowe · Poziom 2 · `sql-insert/szkola/07`

Dodaj rekord (id, nazwa, cena, grupa_id, aktywny): 9, kurs Nowy 7, 119, 1, 0. Zachowaj istniejące dane.

**Dane startowe**

```sql
CREATE TABLE specjalizacje (id INT PRIMARY KEY, nazwa VARCHAR(80) NOT NULL);
CREATE TABLE kursy (id INT PRIMARY KEY, nazwa VARCHAR(80) NOT NULL, cena INT NOT NULL, grupa_id INT NOT NULL, aktywny INT NOT NULL, FOREIGN KEY (grupa_id) REFERENCES specjalizacje(id));
INSERT INTO specjalizacje VALUES (1, 'Podstawowa'), (2, 'Dodatkowa'), (3, 'Sezonowa'), (4, 'Pusta');
INSERT INTO kursy VALUES (1, 'kurs Alfa 7', 131, 1, 0), (2, 'kurs Beta 7', 141, 2, 1), (3, 'kurs Gamma 7', 125, 3, 0), (4, 'kurs Delta 7', 135, 1, 1), (5, 'kurs Epsilon 7', 119, 2, 0), (6, 'kurs Zeta 7', 129, 3, 1), (7, 'kurs Eta 7', 139, 1, 0), (8, 'kurs Iota 7', 123, 2, 1);
```

**Kod lub materiał startowy**

```sql
INSERT INTO kursy (...) VALUES (...);
```

**Podpowiedź**

Podaj nazwy kolumn i wartości w tej samej kolejności.

**Co powinno wyjść**

```json
[
  [
    1,
    "kurs Alfa 7",
    131,
    1,
    0
  ],
  [
    2,
    "kurs Beta 7",
    141,
    2,
    1
  ],
  [
    3,
    "kurs Gamma 7",
    125,
    3,
    0
  ],
  [
    4,
    "kurs Delta 7",
    135,
    1,
    1
  ],
  [
    5,
    "kurs Epsilon 7",
    119,
    2,
    0
  ],
  [
    6,
    "kurs Zeta 7",
    129,
    3,
    1
  ],
  [
    7,
    "kurs Eta 7",
    139,
    1,
    0
  ],
  [
    8,
    "kurs Iota 7",
    123,
    2,
    1
  ],
  [
    9,
    "kurs Nowy 7",
    119,
    1,
    0
  ]
]
```

**Rozwiązanie**

```sql
INSERT INTO kursy (id, nazwa, cena, grupa_id, aktywny) VALUES (9, 'kurs Nowy 7', 119, 1, 0);
```

## Policz koszt z opcjonalną dopłatą

**JavaScript** · Sklep papierniczy · Poziom 1 · `js-koszt/sklep/08`

Napisz rozwiaz(liczba, dodatek). Stawka wynosi 136 zł za sztukę. Gdy dodatek jest true, dolicz 9 zł raz do całego zamówienia.

**Kod lub materiał startowy**

```javascript
function rozwiaz(liczba, dodatek) {
  // zwróć łączny koszt
}
```

**Podpowiedź**

Najpierw pomnóż liczbę sztuk przez stawkę. Dopłatę dodaj na końcu.

**Co powinno wyjść**

- [1,false] → 136
- [3,true] → 417
- [2,false] → 272
- [5,true] → 689

**Rozwiązanie**

```javascript
function rozwiaz(liczba, dodatek) {
  return liczba * 136 + (dodatek ? 9 : 0);
}
```

## Napraw walidację pola

**JavaScript** · Hotel · Poziom 1 · `js-zakres/hotel/09`

W funkcji rozwiaz(tekst) przyjmuj tekst z pola. Zwróć pełną liczbę od 3 do 143 albo null dla pozostałych danych. Dopuść zewnętrzne spacje.

**Kod lub materiał startowy**

```javascript
function rozwiaz(tekst) {
  const n = parseInt(tekst, 10);
  return n >= 3 && n <= 143 ? n : null;
}
```

**Podpowiedź**

parseInt ucina część po przecinku. Użyj Number i Number.isInteger.

**Co powinno wyjść**

- ["3"] → 3
- [" 143 "] → 143
- [""] → null
- ["2"] → null
- ["3.5"] → null
- ["144"] → null

**Rozwiązanie**

```javascript
function rozwiaz(tekst) {
  const n = Number(tekst.trim());
  return tekst.trim() !== "" && Number.isInteger(n) && n >= 3 && n <= 143 ? n : null;
}
```

## Zastosuj rabat od progu

**JavaScript** · Klub sportowy · Poziom 2 · `js-rabat/klub/10`

Napisz rozwiaz(n). Cena jednostkowa to 170 zł. Od 4 sztuk zastosuj rabat 13%. Zwróć koszt jako liczbę groszy.

**Kod lub materiał startowy**

```javascript
function rozwiaz(n) {
  return n * 170 * 100;
}
```

**Podpowiedź**

Sprawdź wynik dokładnie na progu rabatu.

**Co powinno wyjść**

- [1] → 17000
- [3] → 51000
- [4] → 59160
- [5] → 73950

**Rozwiązanie**

```javascript
function rozwiaz(n) {
  const procentCeny = n >= 4 ? 87 : 100;
  return Math.round(n * 170 * procentCeny);
}
```

## Przefiltruj tablicę obiektów

**JavaScript** · Galeria zdjęć · Poziom 2 · `js-filtr/galeria/11`

Funkcja rozwiaz(pozycje) ma zwrócić identyfikatory obiektów z aktywny = 0 i cena ≤ 207. Zachowaj kolejność. Dane przykładowe: [{"id":1,"cena":207,"aktywny":1},{"id":2,"cena":191,"aktywny":1},{"id":3,"cena":201,"aktywny":1},{"id":4,"cena":211,"aktywny":1},{"id":5,"cena":195,"aktywny":1},{"id":6,"cena":205,"aktywny":1},{"id":7,"cena":189,"aktywny":1},{"id":8,"cena":199,"aktywny":1}]

**Kod lub materiał startowy**

```javascript
function rozwiaz(pozycje) {
  return pozycje.map(p => p.id);
}
```

**Podpowiedź**

Najpierw filter, potem map. Testuj również pustą tablicę.

**Co powinno wyjść**

- [[{"id":1,"cena":207,"aktywny":1},{"id":2,"cena":191,"aktywny":1},{"id":3,"cena":201,"aktywny":1},{"id":4,"cena":211,"aktywny":1},{"id":5,"cena":195,"aktywny":1},{"id":6,"cena":205,"aktywny":1},{"id":7,"cena":189,"aktywny":1},{"id":8,"cena":199,"aktywny":1}]] → []
- [[]] → []
- [[{"id":10,"cena":207,"aktywny":0}]] → [10]

**Rozwiązanie**

```javascript
function rozwiaz(pozycje) {
  return pozycje.filter(p => p.aktywny === 0 && p.cena <= 207).map(p => p.id);
}
```

## Napraw pętlę sumującą

**JavaScript** · Szkółka roślin · Poziom 1 · `js-petla/szkolka/12`

Napraw rozwiaz(liczby), by sumowała elementy podzielne przez 6. Dane przykładowe: [226,210,220,204,214,224,208,218].

**Kod lub materiał startowy**

```javascript
function rozwiaz(liczby) {
  let suma = 0;
  for (let i = 1; i <= liczby.length; i++) {
    if (liczby[i] % 6 === 0) suma += liczby[i];
  }
  return suma;
}
```

**Podpowiedź**

Pierwszy indeks to 0, ostatni to długość minus 1.

**Co powinno wyjść**

- [[226,210,220,204,214,224,208,218]] → 414
- [[6,12,1]] → 18
- [[]] → 0
- [[138]] → 138

**Rozwiązanie**

```javascript
function rozwiaz(liczby) {
  let suma = 0;
  for (let i = 0; i < liczby.length; i++) {
    if (liczby[i] % 6 === 0) suma += liczby[i];
  }
  return suma;
}
```

## Podepnij obliczenie pod kliknięcie

**JavaScript** · Pracownia ceramiki · Poziom 2 · `js-dom/pracownia/13`

W istniejącym HTML obsłuż kliknięcie #licz. Pomnóż liczbę z pola #pracownia-13 przez 221 i wyświetl w #wynik z dopiskiem „ zł”. Przy pustej wartości pokaż „Wpisz liczbę”.

**HTML do podglądu**

```html
<label>Liczba <input id="pracownia-13" type="number" value="2"></label>
<button type="button" id="licz">Przelicz</button>
<output id="wynik"></output>
```

**Kod lub materiał startowy**

```javascript
const przycisk = document.querySelector("#licz");
// dodaj obsługę
```

**Podpowiedź**

Użyj addEventListener i textContent. Sprawdź puste value przed Number.

**Co powinno wyjść**

- "2" → "442 zł"
- "" → "Wpisz liczbę"
- "4" → "884 zł"

**Rozwiązanie**

```javascript
const pole = document.getElementById("pracownia-13");
const wynik = document.querySelector("#wynik");
document.querySelector("#licz").addEventListener("click", () => {
  wynik.textContent = pole.value === "" ? "Wpisz liczbę" : (Number(pole.value) * 221) + " zł";
});
```

## Napisz formularz z etykietami

**HTML** · Księgarnia · Poziom 1 · `html-form/ksiegarnia/14`

Zbuduj formularz POST do zapis.php. Pole "ksiegarnia-13" ma przyjąć pełną liczbę od 4 do 228. Dodaj widoczną etykietę i przycisk wysyłki.

**Kod lub materiał startowy**

```html
<form><!-- Wstaw kontrolki. --></form>
```

**Podpowiedź**

Dopasuj for do id, a klucz przesyłany wpisz w name.

**Co powinno wyjść**

- Akcja i metoda są poprawne.
- Kliknięcie etykiety przenosi fokus.
- Formularz sprawdza wartość na obu granicach i odrzuca ułamek.

**Rozwiązanie**

```html
<form action="zapis.php" method="post">
  <label for="ksiegarnia-13">Liczba</label>
  <input type="number" name="ksiegarnia-13" id="ksiegarnia-13" min="4" max="228" step="1" required>
  <button type="submit">Zapisz</button>
</form>
```

## Utwórz czytelną tabelę

**HTML** · Biuro wycieczek · Poziom 1 · `html-tabela/bilety/15`

Utwórz tabelę z podpisem „Biuro wycieczek”, kolumnami „Nazwa” i „Cena” oraz poniższymi wierszami: wycieczka Gamma 15 — 277 zł, wycieczka Delta 15 — 261 zł, wycieczka Epsilon 15 — 271 zł, wycieczka Zeta 15 — 255 zł.

**Kod lub materiał startowy**

```html
<table><!-- Wstaw podpis, nagłówki i wiersze. --></table>
```

**Podpowiedź**

caption podpisuje tabelę. th scope="col" opisuje kolumnę.

**Co powinno wyjść**

- Tabela ma podpis i nagłówki obu kolumn.
- Liczba wierszy danych i kolejność pozycji zgadzają się z zadaniem.

**Rozwiązanie**

```html
<table>
  <caption>Biuro wycieczek</caption>
  <thead><tr><th scope="col">Nazwa</th><th scope="col">Cena</th></tr></thead>
  <tbody>
    <tr><td>wycieczka Gamma 15</td><td>277 zł</td></tr>
    <tr><td>wycieczka Delta 15</td><td>261 zł</td></tr>
    <tr><td>wycieczka Epsilon 15</td><td>271 zł</td></tr>
    <tr><td>wycieczka Zeta 15</td><td>255 zł</td></tr>
  </tbody>
</table>
```

## Połącz semantykę i nawigację

**HTML** · Magazyn sprzętu · Poziom 1 · `html-uklad/magazyn/16`

W widocznym nagłówku strony daj tytuł „Magazyn sprzętu”. Dodaj odnośnik „Oferta” do #sekcja-16. W sekcji oferty wypisz pozycję „urządzenie Iota 16”. Dodaj stopkę.

**Kod lub materiał startowy**

```html
<div>Treść strony</div>
```

**Podpowiedź**

Użyj header, nav, main, section i footer. Sprawdź zgodność href i id.

**Co powinno wyjść**

- Nagłówki mają właściwe poziomy.
- Link przenosi do sekcji oferty.
- Stopka ma własny element.

**Rozwiązanie**

```html
<header><h1>Magazyn sprzętu</h1></header>
<nav><a href="#sekcja-16">Oferta</a></nav>
<main><section id="sekcja-16"><h2>Oferta</h2><p>urządzenie Iota 16</p></section></main>
<footer>Kontakt</footer>
```

## Umieść ilustrację i podpis

**HTML** · Wypożyczalnia rowerów · Poziom 2 · `html-media/wypozyczalnia/01`

Dodaj ilustrację img/wypozyczalnia-1.jpg o wymiarach 480 × 320 px. Opis dla osoby bez obrazu to „rower Alfa 1”. Podpis ma brzmieć „Wypożyczalnia rowerów”.

**Kod lub materiał startowy**

```html
<figure><!-- Wstaw elementy. --></figure>
```

**Podpowiedź**

Opisz zawartość w alt, a podpis ilustracji umieść w figcaption.

**Co powinno wyjść**

- Ścieżka i atrybuty wymiaru są zgodne.
- alt i figcaption mają właściwą treść.

**Rozwiązanie**

```html
<figure>
  <img src="img/wypozyczalnia-1.jpg" alt="rower Alfa 1" width="480" height="320">
  <figcaption>Wypożyczalnia rowerów</figcaption>
</figure>
```

## Ułóż kolumny według projektu

**CSS** · Biblioteka · Poziom 1 · `css-grid/biblioteka/02`

W .karty ustaw 3 równe kolumny i odstęp 9 px. Przy szerokości do 553 px przełącz na jedną kolumnę.

**HTML do podglądu**

```html
<div class="karty"><article>A</article><article>B</article><article>C</article><article>D</article></div>
```

**Kod lub materiał startowy**

```css
.karty { }
@media (...) { }
```

**Podpowiedź**

Połącz repeat() i @media (max-width: ...).

**Co powinno wyjść**

- Liczba kolumn przy 554 px wynosi 3.
- Przy 553 px działa pojedyncza kolumna.
- Odstęp wynosi 9 px.

**Rozwiązanie**

```css
.karty { display: grid; grid-template-columns: repeat(3, 1fr); gap: 9px; }
@media (max-width: 553px) { .karty { grid-template-columns: 1fr; } }
```

## Dobierz precyzyjny selektor

**CSS** · Serwis komputerowy · Poziom 1 · `css-selektor/serwis/03`

Ustaw tło #d9e90c dla parzystych wierszy danych tabeli klasy serwis. Zachowaj obecne tło nagłówka.

**HTML do podglądu**

```html
<table class="serwis"><thead><tr><th>Pozycja</th></tr></thead><tbody><tr><td>A</td></tr><tr><td>B</td></tr><tr><td>C</td></tr></tbody></table>
```

**Kod lub materiał startowy**

```css
/* Wpisz selektor i deklarację. */
```

**Podpowiedź**

Ogranicz selektor do tbody i użyj :nth-child.

**Co powinno wyjść**

- Nagłówek i inna tabela są bez zmian.
- Zaznaczone wiersze mają zgodną parzystość.

**Rozwiązanie**

```css
.serwis tbody tr:nth-child(even) { background-color: #d9e90c; }
```

## Napraw szerokość karty

**CSS** · Kino · Poziom 1 · `css-box/kino/04`

Obrys .karta ma mieć 155 px szerokości. Dodaj po 9 px paddingu i po 4 px obramowania. Napraw szerokość bez ręcznego odejmowania.

**HTML do podglądu**

```html
<article class="karta">Treść</article>
```

**Kod lub materiał startowy**

```css
.karta { width: 155px; padding: 9px; border: 4px solid; }
```

**Podpowiedź**

Włącz box-sizing: border-box.

**Co powinno wyjść**

- Computed border-box ma 155 px.
- Padding i obramowanie są zachowane.
- Treść ma 129 px szerokości.

**Rozwiązanie**

```css
.karta { box-sizing: border-box; width: 155px; padding: 9px; border: 4px solid; }
```

## Ustaw kierunek i odstępy w pasku

**CSS** · Muzeum · Poziom 2 · `css-flex/muzeum/05`

W .muzeum ustaw przyciski pionowo, z odstępem 14 px. Przy maksymalnie 456 px zastosuj układ odwrotny.

**HTML do podglądu**

```html
<nav class="muzeum"><button>A</button><button>B</button><button>C</button></nav>
```

**Kod lub materiał startowy**

```css
.muzeum { }
@media (...) { }
```

**Podpowiedź**

Włącz flex. flex-direction zmienia kierunek elementów.

**Co powinno wyjść**

- Układ zmienia kierunek przy wskazanej szerokości.
- Odstęp jest taki sam w obu układach.

**Rozwiązanie**

```css
.muzeum { display: flex; flex-direction: column; gap: 14px; }
@media (max-width: 456px) { .muzeum { flex-direction: row; } }
```

## Sprawdź dane odebrane z formularza

**PHP** · Kawiarnia · Poziom 1 · `php-zakres/kawiarnia/06`

Napisz rozwiaz($tekst), która zwraca liczbę całkowitą od 4 do 92 z pola formularza. Dla błędnej wartości lub braku pola zwróć null.

**Kod lub materiał startowy**

```php
<?php
function rozwiaz($tekst) {
    return (int) $tekst;
}
```

**Podpowiedź**

Sprawdź typ, potem FILTER_VALIDATE_INT z zakresem.

**Co powinno wyjść**

- ["4"] → 4
- [" 92 "] → 92
- ["93"] → null
- [""] → null
- ["4.4"] → null
- [null] → null

**Rozwiązanie**

```php
<?php
function rozwiaz($tekst) {
    if (!is_string($tekst)) { return null; }
    $n = filter_var(trim($tekst), FILTER_VALIDATE_INT, ["options" => ["min_range" => 4, "max_range" => 92]]);
    return $n === false ? null : $n;
}
```

## Wypisz zewnętrzną treść w HTML

**PHP** · Kursy zawodowe · Poziom 1 · `php-wyjscie/szkola/07`

Napisz rozwiaz($tekst), która generuje akapit z class="szkola-7". Zawartość ma pozostać tekstem nawet wtedy, gdy zawiera nawiasy ostre, cudzysłów lub &.

**Kod lub materiał startowy**

```php
<?php
function rozwiaz($tekst) {
    // zbuduj akapit
}
```

**Podpowiedź**

Zastosuj htmlspecialchars na samej treści. Oczekiwany zapis apostrofu to &#039;.

**Co powinno wyjść**

- ["A & B"] → "<p class=\"szkola-7\">A &amp; B</p>"
- ["<serwis>"] → "<p class=\"szkola-7\">&lt;serwis&gt;</p>"
- ["\"Nowy\""] → "<p class=\"szkola-7\">&quot;Nowy&quot;</p>"
- ["Spotkanie 'A'"] → "<p class=\"szkola-7\">Spotkanie &#039;A&#039;</p>"

**Rozwiązanie**

```php
<?php
function rozwiaz($tekst) {
    return '<p class="szkola-7">' . htmlspecialchars($tekst, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '</p>';
}
```

## Policz sumę w pętli foreach

**PHP** · Sklep papierniczy · Poziom 2 · `php-suma/sklep/08`

Napisz rozwiaz($wiersze) sumującą pole cena, jeśli cena wynosi co najmniej 150. Dane dla Sklep papierniczy: [{"cena":150},{"cena":160},{"cena":144},{"cena":154},{"cena":138},{"cena":148},{"cena":158},{"cena":142}].

**Kod lub materiał startowy**

```php
<?php
function rozwiaz($wiersze) {
    $suma = 0;
    return $suma;
}
```

**Podpowiedź**

Przechodź po wierszach i dodawaj pole cena tylko przy spełnieniu warunku.

**Co powinno wyjść**

- [[{"cena":150},{"cena":160},{"cena":144},{"cena":154},{"cena":138},{"cena":148},{"cena":158},{"cena":142}]] → 622
- [[]] → 0
- [[{"cena":150},{"cena":149}]] → 150

**Rozwiązanie**

```php
<?php
function rozwiaz($wiersze) {
    $suma = 0;
    foreach ($wiersze as $r) {
        if ($r["cena"] >= 150) { $suma += $r["cena"]; }
    }
    return $suma;
}
```

## Wygeneruj listę po SELECT

**PHP** · Hotel · Poziom 3 · `php-select/hotel/09`

Zaimportuj podane dane do ćwiczeniowej bazy. Z istniejącego połączenia $db wypisz w HTML nazwy z pokoje przy cena ≥ 169, w kolejności id rosnącej. Pokaż „Brak wyników”, gdy nic nie pasuje.

**Dane startowe**

```sql
CREATE TABLE standardy (id INT PRIMARY KEY, nazwa VARCHAR(80) NOT NULL);
CREATE TABLE pokoje (id INT PRIMARY KEY, nazwa VARCHAR(80) NOT NULL, cena INT NOT NULL, grupa_id INT NOT NULL, aktywny INT NOT NULL, FOREIGN KEY (grupa_id) REFERENCES standardy(id));
INSERT INTO standardy VALUES (1, 'Podstawowa'), (2, 'Dodatkowa'), (3, 'Sezonowa'), (4, 'Pusta');
INSERT INTO pokoje VALUES (1, 'pokój Alfa 9', 169, 3, 1), (2, 'pokój Beta 9', 153, 1, 0), (3, 'pokój Gamma 9', 163, 2, 1), (4, 'pokój Delta 9', 173, 3, 0), (5, 'pokój Epsilon 9', 157, 1, 1), (6, 'pokój Zeta 9', 167, 2, 0), (7, 'pokój Eta 9', 177, 3, 1), (8, 'pokój Iota 9', 161, 1, 0);
```

**Kod lub materiał startowy**

```php
<?php
// $db to połączenie mysqli

```

**Podpowiedź**

Użyj prepare, bind_param, execute oraz bezpiecznego wypisywania tekstu w li.

**Co powinno wyjść**

- Kolejność nazw: pokój Alfa 9, pokój Delta 9, pokój Eta 9.
- Przy pustym wyniku widoczny jest osobny komunikat.
- Znaki specjalne w nazwach pozostają tekstem.

**Rozwiązanie**

```php
<?php
$stmt = $db->prepare('SELECT nazwa FROM pokoje WHERE cena >= ? ORDER BY id ASC');
$prog = 169;
$stmt->bind_param("i", $prog);
$stmt->execute();
$stmt->bind_result($nazwa);
$items = [];
while ($stmt->fetch()) {
    $items[] = "<li>" . htmlspecialchars($nazwa, ENT_QUOTES | ENT_SUBSTITUTE, "UTF-8") . "</li>";
}
echo $items ? "<ul>" . implode("", $items) . "</ul>" : "<p>Brak wyników</p>";
$stmt->close();
```

## Dobierz format i rozmiar pliku

**Grafika** · Klub sportowy · Poziom 1 · `grafika-eksport/klub/10`

Przygotuj ilustrację dla „Klub sportowy” o wymiarach 572 × 429 px. Użyj zdjęcia bez przezroczystości i zmieść się w 218 kB. Zapisz jako klub.jpg.

**Kod lub materiał startowy**

```text
Weź własne zdjęcie lub utwórz ikonę w edytorze.
```

**Podpowiedź**

Przytnij do 4:3 przed zmianą wielkości, a następnie przygotuj eksport.

**Co powinno wyjść**

- Wymiary i rozszerzenie są zgodne.
- Plik mieści się w limicie 218 kB.
- Obraz zachował proporcje.

**Rozwiązanie**

```text
Ustaw kadr 4:3, przeskaluj do 572 × 429 px i wyeksportuj JPEG, w razie potrzeby ustaw niższą jakość przy zachowaniu wymiarów.
```
