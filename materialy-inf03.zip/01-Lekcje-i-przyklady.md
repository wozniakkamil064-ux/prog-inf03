# INF.03 Lekcje i przykłady

Wybierz temat, przeczytaj regułę i uruchom przykład w odpowiednim środowisku. Fragmenty zależne od elementu, formularza lub połączenia wykonuj w kontekście opisanym w lekcji. Następnie wykonaj polecenie z pamięci.

## Środowisko i obsługa egzaminu

Zakres efektów INF.03: 03.2, 03.3, 03.4, 03.5.

**Po tym module**

Uruchom stronę przez localhost, zaimportuj bazę testową i przygotuj zestaw plików zgodny z poleceniem.

### Pliki i ścieżki

***Priorytet egzaminacyjny***

Adres względny jest liczony względem położenia dokumentu. Nazwa i rozszerzenie zasobu muszą zgadzać się z arkuszem.

```text
zadanie/
  index.php
  style.css
  app.js
  img/rower.jpg
```

**Pułapka**

Sprawdź wielkość liter i ukryte rozszerzenia plików.

**Sprawdź się**

Jaka ścieżka w index.php prowadzi do rower.jpg?

### Co robi przeglądarka, Apache i baza

***Priorytet egzaminacyjny***

Przeglądarka renderuje HTML/CSS i uruchamia JS. Apache z PHP wykonuje skrypt na serwerze, a MySQL/MariaDB zwraca dane z zapytania.

```text
przeglądarka → Apache/PHP → baza
przeglądarka ← gotowy HTML ← PHP
```

**Pułapka**

Dwuklik pliku PHP nie uruchomi go po stronie serwera.

**Sprawdź się**

Otwórz plik przez http://localhost/zadanie/ i porównaj źródło strony z plikiem PHP.

### Podgląd i konsola

***Priorytet egzaminacyjny***

Sprawdź Console przy błędzie skryptu, Network przy błędzie ładowania plików i Elements przy rozbieżnym CSS.

```javascript
console.log(document.querySelector("#wynik"));
```

**Pułapka**

Wynik null oznacza brak pasującego elementu w chwili wyszukania.

**Sprawdź się**

Co sprawdzisz przy czerwonym 404 dla style.css?

### Polecenie na rezultaty

***Priorytet egzaminacyjny***

Wypisz pliki, ich formaty, zrzuty, skrypty i wymagane zachowania. Zanotuj, co da się sprawdzić po każdym etapie.

```text
[ ] import i zrzut
[ ] kwerendy i wyniki
[ ] strona, styl, skrypt
[ ] kontrola nazw przy oddaniu
```

**Pułapka**

Nazwa pliku i format zrzutu zależą od konkretnego polecenia.

**Sprawdź się**

Wybierz arkusz i zrób listę plików w kolejności wykonania.

## HTML od zera

Zakres efektów INF.03: 03.3.

**Po tym module**

Zbuduj poprawny dokument z nawigacją, obrazem, tabelą i formularzem, korzystając z osobnego CSS.

### Szkielet dokumentu

***Priorytet egzaminacyjny***

DOCTYPE wybiera współczesny tryb renderowania. W html podaj język, a w head kodowanie, viewport, tytuł i zasoby.

```html
<!doctype html>
<html lang="pl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Cennik</title>
  <link rel="stylesheet" href="style.css">
  <script src="app.js" defer></script>
</head>
<body><h1>Cennik</h1></body>
</html>
```

**Pułapka**

DOCTYPE jest deklaracją. title ustawia tytuł zakładki, h1 tytuł treści.

**Sprawdź się**

Napisz szkielet z pamięci i sprawdź polskie litery.

### Semantyka układu i nagłówki

***Priorytet egzaminacyjny***

header, nav, main, section, article, aside i footer informują o roli zawartości. Poziom nagłówka odzwierciedla hierarchię.

```html
<header><h1>Katalog</h1></header>
<main><section><h2>Oferta</h2><p>Trzy modele.</p></section></main>
<footer>Kontakt</footer>
```

**Pułapka**

Sam rozmiar tekstu ustaw CSS-em.

**Sprawdź się**

Zamień szereg divów na czytelny układ semantyczny.

### Atrybuty i elementy puste

***Priorytet egzaminacyjny***

id identyfikuje pojedynczy element. class możesz nadawać wielu elementom. data-* przechowuje dane pomocnicze. img, input, meta i link są elementami pustymi.

```html
<img id="miniatura" class="foto" src="a.jpg" alt="Rower">
<button type="button" data-cena="14">Wybierz</button>
```

**Pułapka**

Powtórzony identyfikator komplikuje JS i odnośniki.

**Sprawdź się**

Rozpoznaj, które atrybuty można bezpiecznie powtórzyć.

### Linki i kotwice

***Priorytet egzaminacyjny***

href może prowadzić do pliku, pełnego URL albo fragmentu z id. Tekst linku powinien opisywać cel.

```html
<a href="oferta.html">Oferta</a>
<a href="#kontakt">Kontakt</a>
<section id="kontakt"><h2>Kontakt</h2></section>
```

**Pułapka**

Adres #kontakt zadziała, jeśli w dokumencie istnieje id="kontakt".

**Sprawdź się**

Dodaj odnośnik z podfolderu do pliku poziom wyżej.

### Obraz i tekst alternatywny

***Priorytet egzaminacyjny***

src podaje ścieżkę. alt przekazuje informację potrzebną po pominięciu obrazu, a alt="" oznacza dekorację.

```html
<figure>
  <img src="img/mapa.png" alt="Trasa od dworca do parku">
  <figcaption>Trasa A</figcaption>
</figure>
```

**Pułapka**

Nazwa pliku zwykle mało mówi o treści obrazu.

**Sprawdź się**

Zapisz trafny alt mapy, zdjęcia produktu i ikony dekoracyjnej.

### Listy i zagnieżdżanie

***Priorytet egzaminacyjny***

ol oznacza kolejność, ul wypunktowanie, li pozycję. Listę zagnieżdżoną umieszczaj wewnątrz li.

```html
<ol><li>Importuj bazę</li><li>Wykonaj zapytania</li></ol>
```

**Pułapka**

Bezpośrednio wewnątrz ul i ol dodawaj pozycje li.

**Sprawdź się**

Zapisz listę kroków i podlistę plików.

### Tabele danych

***Priorytet egzaminacyjny***

table zawiera wiersze tr, a tr komórki th lub td. caption opisuje tabelę, a scope powiązanie nagłówka.

```html
<table>
  <caption>Cennik</caption>
  <thead><tr><th scope="col">Usługa</th><th scope="col">Cena</th></tr></thead>
  <tbody><tr><td>Serwis</td><td>49 zł</td></tr></tbody>
</table>
```

**Pułapka**

colspan łączy kolumny, rowspan wiersze.

**Sprawdź się**

Dodaj wiersz komunikatu obejmujący dwie kolumny.

### Formularz i wysyłka

***Priorytet egzaminacyjny***

action wskazuje odbiorcę. GET przekazuje pola w adresie, POST w ciele żądania. name to klucz odebrany przez serwer.

```html
<form action="zapis.php" method="post">
  <label for="email">E-mail</label>
  <input id="email" name="email" type="email" required>
  <button type="submit">Zapisz</button>
</form>
```

**Pułapka**

for odwołuje się do id, a PHP odczytuje name. Weryfikacja w HTML wspiera użytkownika i trzeba ją powtórzyć w PHP.

**Sprawdź się**

Napisz formularz POST, którym PHP otrzyma klucz email.

### Pola wyboru i przyciski

***Priorytet egzaminacyjny***

Radio z taką samą nazwą działa jako grupa. Checkbox może nie trafić do żądania, jeśli jest odznaczony. option value jest wartością wysyłaną.

```html
<label><input type="radio" name="tryb" value="1"> Standard</label>
<label><input type="radio" name="tryb" value="2"> Premium</label>
<button type="button">Przelicz</button>
```

**Pułapka**

Przycisk w formularzu domyślnie może wysłać formularz.

**Sprawdź się**

Zbuduj select z dwiema opcjami i opcjonalny checkbox.

### Multimedia i dostępność

***Uzupełnienie***

Dodaj sterowanie odtwarzaczem, napisy do wideo, nazwy kontrolek, logiczną kolejność fokusu i napisy zamiast wskazówek wyłącznie kolorem.

```html
<video controls src="instrukcja.mp4">
  <track kind="captions" src="pl.vtt" srclang="pl" label="Polskie">
</video>
```

**Pułapka**

div z obsługą kliknięcia nie przejmuje zachowania klawiaturowego button.

**Sprawdź się**

Przejdź formularz i menu wyłącznie klawiszem Tab.

## CSS od selektorów do układu

Zakres efektów INF.03: 03.3.

**Po tym module**

Odtwórz dwukolumnowy układ arkusza i przypisz style tylko elementom wskazanym w poleceniu.

### Zewnętrzny arkusz i selektory

***Priorytet egzaminacyjny***

Selektor typu wskazuje tag, kropka klasę, kratka identyfikator. Przecinek grupuje niezależne selektory.

```css
p { color: #222; }
.karta { padding: 12px; }
#wynik { font-weight: 700; }
h1, h2 { margin-top: 0; }
```

**Pułapka**

.karta i #karta oznaczają różne atrybuty.

**Sprawdź się**

Ustaw jeden kolor dla h1 i h2 bez powtarzania deklaracji.

### Relacje, atrybuty i pseudoklasy

***Priorytet egzaminacyjny***

A B wybiera potomka, A > B dziecko, plus sąsiedniego brata. :hover, :focus-visible i :nth-child testują stan lub pozycję elementu.

```css
nav > a:hover { color: #b11; }
input[type="email"]:focus-visible { outline: 2px solid navy; }
tbody tr:nth-child(even) { background: #eee; }
```

**Pułapka**

tbody w selektorze pomaga zachować kolor nagłówka tabeli.

**Sprawdź się**

Zaznacz tylko parzyste wiersze danych.

### Kaskada i dziedziczenie

***Priorytet egzaminacyjny***

Przeglądarka rozstrzyga m.in. ważność i pochodzenie reguły, specyficzność oraz kolejność. W tym samym poziomie kaskady id przebija klasę, a późniejszy remis wygrywa.

```css
#cena { color: purple; }
.wyroznione { color: green; }
.wyroznione { color: navy; }
```

**Pułapka**

Dziedziczy się m.in. color, ale margin elementu nadrzędnego nie przechodzi na dziecko.

**Sprawdź się**

Jaki kolor otrzyma element przy samym class i przy obu atrybutach?

### Box model i jednostki

***Priorytet egzaminacyjny***

Padding jest wewnątrz obramowania, margin na zewnątrz. border-box wlicza padding i obramowanie do podanej szerokości.

```css
.karta { box-sizing: border-box; width: 240px; padding: 12px; border: 2px solid; margin: 8px; }
```

**Pułapka**

Przy content-box zewnętrzny obrys to tu 268px bez marginesów.

**Sprawdź się**

Policz szerokość obrysu tego elementu przy border-box.

### Kolory, tło i tekst

***Priorytet egzaminacyjny***

W szesnastkowym #RRGGBB każda para koduje kanał. font-family podaje listę krojów, text-align wyrównuje treść w obszarze elementu.

```css
body { color: #18202b; background-color: #f3f4f6; font-family: Arial, sans-serif; }
header { text-align: center; }
```

**Pułapka**

color to kolor tekstu, background-color to tło.

**Sprawdź się**

Ustaw tło i kolor stopki bez wpływu na resztę dokumentu.

### Flexbox

***Priorytet egzaminacyjny***

Rodzic z display:flex układa dzieci wzdłuż osi głównej. justify-content rozkłada je na osi głównej, align-items poprzecznie.

```css
.panel { display: flex; gap: 16px; align-items: start; }
.lewy { flex: 2; }
.prawy { flex: 1; }
```

**Pułapka**

Zmiana flex-direction zmienia osie.

**Sprawdź się**

Ustaw dwa panele 2:1 i sprawdź ich układ po zmianie kierunku.

### Grid i breakpointy

***Priorytet egzaminacyjny***

Grid definiuje tory kolumn i wierszy. Query wybiera zestaw reguł według szerokości obszaru wyświetlania.

```css
.karty { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }
@media (max-width: 650px) { .karty { grid-template-columns: 1fr; } }
```

**Pułapka**

Sprawdź obie strony granicy, np. 650 i 651 px.

**Sprawdź się**

Odtwórz proporcję 2:1 i przełącz na jedną kolumnę.

### Float i pozycjonowanie

***Uzupełnienie***

float pozwala tekstowi opływać element i pojawia się w starszych układach. clear usuwa opływanie obok poprzednich floatów. Absolute liczy położenie względem właściwego kontenera pozycjonowanego.

```css
.foto { float: left; margin-right: 12px; }
footer { clear: both; }
.karta { position: relative; }
.etykieta { position: absolute; top: 0; right: 0; }
```

**Pułapka**

Sam position:relative nie układa dzieci w kolumnach.

**Sprawdź się**

Pokaż podgląd po usunięciu clear w przykładzie z kolumnami float.

### Tabele, obrazy i przewijanie

***Uzupełnienie***

border-collapse scala krawędzie komórek. max-width chroni przed wystawaniem obrazu. Obiekt może zachować proporcje w prostokącie przez object-fit.

```css
table { border-collapse: collapse; width: 100%; }
th, td { border: 1px solid #555; padding: .4rem; }
img { max-width: 100%; height: auto; }
```

**Pułapka**

width i height wymuszone niezależnie mogą zdeformować obraz.

**Sprawdź się**

Przetestuj tabelę z bardzo długą komórką na telefonie.

## SQL i bazy danych od zera

Zakres efektów INF.03: 03.4.

**Po tym module**

Zaimportuj bazę, napisz kwerendy z JOIN i agregacją, wykonaj kontrolowany UPDATE i udokumentuj wyniki.

### Tabele, rekordy, klucze i typy

***Priorytet egzaminacyjny***

Klucz główny jednoznacznie wskazuje wiersz. Klucz obcy odwołuje się do identyfikatora w innej tabeli. W MariaDB typ DECIMAL sprawdza się dla kwot.

```sql
CREATE TABLE typy (id INT PRIMARY KEY, nazwa VARCHAR(80));
CREATE TABLE rowery (id INT PRIMARY KEY, typ_id INT, stawka DECIMAL(7,2), FOREIGN KEY (typ_id) REFERENCES typy(id));
```

**Pułapka**

Typ liczbowy nie zastępuje poprawnego klucza relacji.

**Sprawdź się**

Rozpisz relację jeden-do-wielu dla kategorii i produktów.

### Normalizacja i więzy

***Uzupełnienie***

Wydziel powtarzalne słowniki, aby zmiana nazwy typu wymagała jednej aktualizacji. NOT NULL wymaga wartości, UNIQUE ogranicza duplikaty.

```sql
CREATE TABLE kategorie (id INT PRIMARY KEY, nazwa VARCHAR(80) NOT NULL UNIQUE);
```

**Pułapka**

Id kategorii w produktach może się powtarzać.

**Sprawdź się**

Uzasadnij podział arkusza produktów na dwie tabele.

### SELECT, alias i DISTINCT

***Priorytet egzaminacyjny***

SELECT wybiera kolumny, FROM tabelę. AS nadaje alias w wyniku. DISTINCT usuwa powtórzenia całego zestawu wybranych kolumn.

```sql
SELECT nazwa, stawka AS cena_godziny FROM rowery;
SELECT DISTINCT typ_id FROM rowery;
```

**Pułapka**

SELECT * może dać kolumny, których zadanie nie wymaga.

**Sprawdź się**

Zwróć dokładnie dwie wskazane kolumny, w podanej kolejności.

### WHERE i wzorce

***Priorytet egzaminacyjny***

WHERE wybiera pojedyncze rekordy. LIKE rozpoznaje % jako dowolny ciąg i _ jako jeden znak. IS NULL testuje brak wartości.

```sql
SELECT nazwa FROM rowery
WHERE dostepny = 1 AND (nazwa LIKE 'M%' OR nazwa LIKE 'R%');
```

**Pułapka**

Grupuj AND i OR nawiasami. Kolumny z NULL sprawdzaj przez IS NULL.

**Sprawdź się**

Wyszukaj nazwy kończące się na „k” z pominięciem niedostępnych.

### Sortowanie i LIMIT

***Priorytet egzaminacyjny***

ORDER BY wybiera kolejność, ASC rosnąco, DESC malejąco. Podaj dodatkową kolumnę przy remisach, jeśli kolejność ma znaczenie.

```sql
SELECT nazwa, stawka FROM rowery
ORDER BY stawka ASC, nazwa ASC LIMIT 3;
```

**Pułapka**

Bez ORDER BY baza nie gwarantuje kolejności wyniku.

**Sprawdź się**

Podaj dwie najdroższe oferty. Przy remisie posortuj po nazwie.

### INNER JOIN i LEFT JOIN

***Priorytet egzaminacyjny***

INNER JOIN zwraca pasujące pary. LEFT JOIN zachowuje również wiersze z lewej tabeli bez dopasowania. Warunek ON opisuje relację.

```sql
SELECT r.nazwa, t.nazwa AS typ
FROM rowery AS r INNER JOIN typy AS t ON r.typ_id = t.id;
```

**Pułapka**

Warunek prawej tabeli w WHERE może usunąć niezłączone wiersze.

**Sprawdź się**

Wyświetl wszystkie kategorie, także puste.

### COUNT, SUM, AVG, MIN, MAX

***Priorytet egzaminacyjny***

COUNT(*) liczy wiersze. COUNT(kolumna) liczy wartości różne od NULL. Pozostałe agregaty liczą sumę, średnią lub skrajne wartości.

```sql
SELECT COUNT(*) AS liczba, AVG(stawka) AS srednia
FROM rowery WHERE dostepny = 1;
```

**Pułapka**

COUNT(*) po LEFT JOIN daje 1 dla zachowanej pustej grupy. Wtedy policz id po prawej.

**Sprawdź się**

Oblicz liczbę i najwyższą cenę dostępnych produktów.

### GROUP BY i HAVING

***Priorytet egzaminacyjny***

GROUP BY scala wiersze w grupy. WHERE filtruje przed grupowaniem, HAVING po zbudowaniu grup.

```sql
SELECT typ_id, COUNT(*) AS liczba FROM rowery
WHERE dostepny = 1 GROUP BY typ_id HAVING COUNT(*) >= 2;
```

**Pułapka**

W prostych kwerendach wszystkie nieagregowane wybrane kolumny dodaj do GROUP BY.

**Sprawdź się**

Policz modele osobno dla typów i pokaż grupy liczące ponad dwa.

### INSERT, UPDATE, DELETE

***Priorytet egzaminacyjny***

INSERT dodaje rekord. UPDATE zmienia wartości, DELETE usuwa rekordy. Przed zmianą wykonaj SELECT z tym samym WHERE.

```sql
SELECT id, stawka FROM rowery WHERE id = 4;
UPDATE rowery SET stawka = 17.50 WHERE id = 4;
SELECT id, stawka FROM rowery WHERE id = 4;
```

**Pułapka**

Bez WHERE UPDATE lub DELETE może objąć wszystkie wiersze.

**Sprawdź się**

Zmień cenę jednego rekordu i potwierdź, że pozostałe ceny nie zmieniły się.

### CREATE, ALTER i widoki

***Uzupełnienie***

CREATE TABLE zakłada strukturę. ALTER TABLE ją zmienia. Widok przechowuje definicję zapytania jako obiekt bazy.

```sql
ALTER TABLE rowery ADD COLUMN opis VARCHAR(120);
CREATE VIEW dostepne_rowery AS SELECT id, nazwa FROM rowery WHERE dostepny = 1;
```

**Pułapka**

DROP usuwa obiekt, a DELETE rekordy z tabeli.

**Sprawdź się**

Dodaj kolumnę statusu i zbuduj widok z filtrem.

### Import, eksport i uprawnienia

***Uzupełnienie***

Wczytaj plik SQL do właściwej bazy i sprawdź tabele. W ćwiczeniowej MariaDB GRANT przydziela określone prawo na danym obiekcie.

```sql
GRANT SELECT ON inf03.rowery TO 'czytelnik'@'localhost';
```

**Pułapka**

Polecenie zakłada istniejącego użytkownika. Uprawnienia ćwicz na własnej bazie.

**Sprawdź się**

Wykonaj eksport, odtwórz go w nowej testowej bazie i sprawdź liczbę wierszy.

### Transakcje i podzapytania

***Uzupełnienie***

Podzapytanie może zwrócić wartość do porównania. W transakcyjnej tabeli InnoDB ROLLBACK wycofuje niezapisane zmiany danych.

```sql
SELECT nazwa FROM rowery WHERE stawka > (SELECT AVG(stawka) FROM rowery);
START TRANSACTION;
UPDATE rowery SET stawka = 20 WHERE id = 4;
ROLLBACK;
```

**Pułapka**

W MySQL i MariaDB wiele poleceń DDL powoduje niejawny COMMIT.

**Sprawdź się**

Wyszukaj ceny ponad średnią i sprawdź wycofanie aktualizacji.

## JavaScript od zmiennej do interfejsu

Zakres efektów INF.03: 03.5.

**Po tym module**

Napisz od podstaw kalkulator lub galerię, obsłuż błędne wejście i potwierdź działanie dla wartości granicznych.

### Zmienne, typy i konwersja

***Priorytet egzaminacyjny***

const wiąże nazwę bez możliwości ponownego przypisania, let dopuszcza zmianę. Pole formularza zwraca tekst.

```javascript
const tekst = "12";
console.log(tekst + 5); // "125"
console.log(Number(tekst) + 5); // 17
```

**Pułapka**

Number("") zwraca 0. Puste wejście sprawdź przed konwersją.

**Sprawdź się**

Przewidź wyniki działań z liczbą i tekstem.

### Warunki i porównania

***Priorytet egzaminacyjny***

=== porównuje bez konwersji typu. && wymaga obu prawdziwych warunków. Operator reszty z dzielenia pozwala sprawdzić parzystość.

```javascript
if (x >= 1 && x <= 8) { console.log("Poprawny zakres"); }
const parzysta = x % 2 === 0;
```

**Pułapka**

Połączenie nierówności 1 <= x <= 8 nie działa jak zapis matematyczny.

**Sprawdź się**

Zapisz warunek na pełną liczbę od 1 do 8.

### Pętle i wynik kodu

***Priorytet egzaminacyjny***

Rozpisz kolejne wartości licznika i zmiennej akumulującej. Indeksy tablic zaczynają się od zera.

```javascript
let suma = 0;
for (let i = 0; i < 4; i++) { suma += i; }
console.log(suma); // 6
```

**Pułapka**

i <= tablica.length próbuje wejść za ostatnią pozycję.

**Sprawdź się**

Zapisz tabelkę i, suma dla wariantu zaczynającego od 1.

### Tablice i obiekty

***Priorytet egzaminacyjny***

Tablica przechowuje kolejność wartości. Obiekt pozwala nazwać właściwości. filter wybiera część tablicy, map przekształca elementy.

```javascript
const rowery = [{ cena: 12, dostepny: true }, { cena: 18, dostepny: false }];
const ceny = rowery.filter(r => r.dostepny).map(r => r.cena);
```

**Pułapka**

filter zwraca nową tablicę.

**Sprawdź się**

Wybierz dostępne modele poniżej ceny granicznej.

### Funkcje i zwracanie wartości

***Priorytet egzaminacyjny***

Parametry przekazują argumenty do funkcji. return oddaje wynik i kończy wywołanie.

```javascript
function koszt(cena, godziny) {
  return cena * godziny;
}
console.log(koszt(12.5, 4)); // 50
```

**Pułapka**

console.log wyświetla informację, lecz nie zastępuje return.

**Sprawdź się**

Napisz funkcję liczącą koszt z rabatem od czterech godzin.

### DOM i wybór elementu

***Priorytet egzaminacyjny***

querySelector oczekuje selektora CSS i zwraca pierwszy element albo null. getElementById oczekuje samego id.

```javascript
const wynik = document.querySelector("#wynik");
wynik.textContent = "Gotowe";
```

**Pułapka**

getElementById("#wynik") szuka id zawierającego kratkę.

**Sprawdź się**

Napraw selektor i zmień tekst w wybranym akapicie.

### Zdarzenia i formularz

***Priorytet egzaminacyjny***

click reaguje na kliknięcie, input na bieżącą zmianę wartości, submit na wysyłkę. W lokalnym kalkulatorze preventDefault blokuje przeładowanie.

```javascript
const form = document.querySelector("form");
form.addEventListener("submit", event => {
  event.preventDefault();
  document.querySelector("#wynik").textContent = "Obliczono";
});
```

**Pułapka**

W addEventListener przekazujesz funkcję. Wywołanie z () wykona ją od razu.

**Sprawdź się**

Policz koszt po Enter i po kliknięciu przycisku.

### Walidacja i formatowanie liczby

***Priorytet egzaminacyjny***

Sprawdź pusty tekst, poprawność liczby i granice. toFixed tworzy tekst z liczbą miejsc po przecinku. Intl.NumberFormat lokalizuje zapis.

```javascript
const tekst = pole.value.trim();
const n = Number(tekst);
if (tekst !== "" && Number.isInteger(n) && n >= 1 && n <= 8) {
  wynik.textContent = new Intl.NumberFormat("pl-PL", { style: "currency", currency: "PLN" }).format(n * 12.5);
}
```

**Pułapka**

parseInt("2.7", 10) daje 2, więc sam nie wykryje wpisania ułamka.

**Sprawdź się**

Przetestuj "", 0, 1, 8, 9 i 1.5.

### Galeria, klasy i lista elementów

***Priorytet egzaminacyjny***

Zmieniaj src wraz z alt. classList.toggle steruje klasą. querySelectorAll pozwala iterować po wszystkich trafieniach.

```javascript
document.querySelectorAll(".miniatura").forEach(mini => {
  mini.addEventListener("click", () => {
    duze.src = mini.src;
    duze.alt = mini.alt;
  });
});
```

**Pułapka**

Dla dostępnej miniatury rozważ zagnieżdżenie obrazu w button i zdarzenie na przycisku.

**Sprawdź się**

Dodaj zmianę zdjęcia i tekstu alternatywnego dla trzech przycisków.

### Algorytmy, obiekty i biblioteki

***Uzupełnienie***

Przeszukiwanie liniowe sprawdza kolejne elementy. Klasa grupuje stan i zachowanie. W zadaniach pisemnych czytaj też składnię przykładów z bibliotek, np. jQuery.

```javascript
const trafienie = [5, 9, 17].find(x => x > 8); // 9
class Licznik {
  stan = 0;
  dodaj() { this.stan++; }
}
```

**Pułapka**

find zwraca pierwsze trafienie albo undefined, filter tablicę wszystkich trafień.

**Sprawdź się**

Rozpisz liczbę sprawdzeń find dla trafienia i braku wyniku.

## PHP od formularza do bazy

Zakres efektów INF.03: 03.5.

**Po tym module**

Odbierz dane, odczytaj pasujące rekordy oraz wygeneruj stronę z obsługą pustej listy.

### Składnia i osadzenie w HTML

***Priorytet egzaminacyjny***

PHP działa na serwerze. Zmienne zaczynają się od znaku $. Kropka łączy teksty. echo wypisuje fragment odpowiedzi.

```php
<?php
$model = 'Rondo';
echo '<p>Model: ' . $model . '</p>';
```

**Pułapka**

Ten przykład wypisuje stałą. Dla danych wejściowych koduj tekst do HTML.

**Sprawdź się**

Wypisz znacznik p z ceną i dopiskiem zł.

### Warunki, tablice i foreach

***Priorytet egzaminacyjny***

Tablica asocjacyjna mapuje nazwy kluczy na wartości. foreach przechodzi po rekordach bez ręcznego indeksu.

```php
<?php
$rowery = [['nazwa' => 'Most', 'cena' => 15]];
foreach ($rowery as $rower) {
    echo htmlspecialchars($rower['nazwa'], ENT_QUOTES, 'UTF-8');
}
```

**Pułapka**

Tablicę asocjacyjną czytaj po kluczu użytym przy tworzeniu lub w wyniku SQL.

**Sprawdź się**

Policz sumę cen dla trzech rekordów.

### GET, POST i walidacja

***Priorytet egzaminacyjny***

Sprawdzaj typ, brak wartości i zakres na serwerze. Opcja min_range w FILTER_VALIDATE_INT pomaga odrzucić liczbę poniżej zakresu.

```php
<?php
$sztuki = filter_input(INPUT_POST, 'sztuki', FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 8]]);
if ($sztuki === false || $sztuki === null) { echo 'Podaj od 1 do 8 sztuk.'; }
```

**Pułapka**

false oznacza niepoprawną wartość, null brak wejścia.

**Sprawdź się**

Sprawdź reakcję PHP na pustą wartość i liczbę 9.

### Dane na wyjściu HTML

***Priorytet egzaminacyjny***

htmlspecialchars koduje znaki specjalne dla kontekstu HTML. Przy dynamicznej treści i atrybutach tekstowych stosuj kodowanie przed wypisaniem.

```php
<?php
$tekst = 'Naprawa & serwis';
echo '<p>' . htmlspecialchars($tekst, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '</p>';
```

**Pułapka**

Kodowanie HTML nie zastępuje parametrów SQL.

**Sprawdź się**

Przewidź HTML źródłowy wyprodukowany dla nazwy „A & B”.

### Połączenie mysqli i SELECT

***Priorytet egzaminacyjny***

Podaj host, konto, hasło i bazę. Ustaw utf8mb4. query wykona stałe zapytanie, a fetch_assoc pobierze wiersz według nazw kolumn.

```php
<?php
$db = new mysqli('localhost', 'uczen', 'haslo_lokalne', 'inf03');
$db->set_charset('utf8mb4');
$wynik = $db->query('SELECT nazwa FROM rowery ORDER BY nazwa');
while ($r = $wynik->fetch_assoc()) {
    echo '<li>' . htmlspecialchars($r['nazwa'], ENT_QUOTES, 'UTF-8') . '</li>';
}
$db->close();
```

**Pułapka**

Dane logowania dopasuj do ćwiczeniowego środowiska. Kod listy opakuj w ul.

**Sprawdź się**

Przerób pętlę na wiersze tabeli.

### Parametry zapytań i zapis

***Priorytet egzaminacyjny***

prepare oddziela konstrukcję zapytania od wartości. bind_param przyjmuje typy m.in. i dla int i s dla string. Nazwy tabel są częścią ustalonej składni.

```php
<?php
$stmt = $db->prepare('UPDATE rowery SET nazwa = ? WHERE id = ?');
$stmt->bind_param('si', $nazwa, $id);
$stmt->execute();
```

**Pułapka**

Zwaliduj id i treść przed wykonaniem. Parametry nie służą do podstawiania nazw kolumn.

**Sprawdź się**

Napisz INSERT z dwiema wartościami podanymi jako parametry.

### Wynik pusty i format danych

***Priorytet egzaminacyjny***

Podaj czytelny komunikat dla braku wyników. number_format pozwala wyświetlić kwotę z polskim separatorem dziesiętnym.

```php
<?php
if ($wynik->num_rows === 0) { echo '<p>Brak danych.</p>'; }
echo number_format(12.5, 2, ',', ' ') . ' zł';
```

**Pułapka**

Wartość wyświetlana jako „12,50 zł” nie nadaje się jako surowy operand JS.

**Sprawdź się**

Wyświetl kwotę w td, a surową wartość liczbową w data-cena.

### Sesje, ciasteczka i pliki

***Uzupełnienie***

session_start wznawia lub tworzy sesję. Dane sesji są po stronie serwera. Ciasteczko klient przesyła w nagłówkach żądań.

```php
<?php
session_start();
$_SESSION['widoki'] = ($_SESSION['widoki'] ?? 0) + 1;
echo (int) $_SESSION['widoki'];
```

**Pułapka**

session_start i setcookie wykonaj przed wysłaniem treści.

**Sprawdź się**

Zobacz, jak działa licznik w dwóch osobnych oknach prywatnych.

## Grafika, multimedia i publikowanie

Zakres efektów INF.03: 03.3, 03.5.

**Po tym module**

Przygotuj pliki o podanych rozmiarach i formatach oraz sprawdź aplikację po opublikowaniu.

### Raster, wektor i formaty

***Priorytet egzaminacyjny***

Raster przechowuje piksele, wektor opisuje kształty. JPEG pasuje do zdjęć, PNG do przezroczystych grafik, SVG do skalowalnych ikon. WebP może obsługiwać przezroczystość.

```text
zdjęcie → JPEG lub WebP
ikona z kanałem alfa → PNG
logo skalowane bez artefaktów → SVG
```

**Pułapka**

W arkuszu pierwszeństwo ma podany format. Zmiana rozszerzenia nie konwertuje obrazu.

**Sprawdź się**

Wybierz format dla zdjęcia, zrzutu i logo oraz uzasadnij każdy.

### Kadrowanie, skalowanie i eksport

***Priorytet egzaminacyjny***

Kadrowanie wybiera obszar. Skalowanie zmienia wymiary w pikselach. Zachowanie proporcji pozwala uniknąć deformacji.

```text
źródło 1800 × 1200 → połowa wymiarów → 900 × 600 px
```

**Pułapka**

Rozmiar pliku w KB to inna rzecz niż szerokość i wysokość w px.

**Sprawdź się**

Przytnij obraz do 3:2, wyeksportuj 900 × 600 i sprawdź wymiary.

### Kanał alfa i kolory

***Priorytet egzaminacyjny***

Alfa opisuje przezroczystość. W RGB kanały czerwony, zielony i niebieski składają się na kolor ekranu.

```css
.panel { background: rgb(40 50 180 / 50%); }
```

**Pułapka**

Przezroczyste tło obrazu sprawdź na jasnym i ciemnym tle.

**Sprawdź się**

Wyeksportuj ikonę PNG i sprawdź krawędzie na kontrastowym tle.

### CMS i hosting

***Uzupełnienie***

CMS zarządza treścią za pomocą panelu i szablonów. Hosting statyczny udostępnia gotowe pliki. PHP i MariaDB wymagają środowiska serwerowego z odpowiednimi usługami.

```text
HTML/CSS/JS → hosting statyczny
PHP + MariaDB → serwer PHP + połączenie z bazą
```

**Pułapka**

Lokalny adres localhost nie jest publicznym adresem dla innych urządzeń.

**Sprawdź się**

Wybierz typ hostingu dla portfolio i formularza z zapisem do bazy.

### Test publikacji i ścieżki

***Uzupełnienie***

Po przesłaniu plików odtwórz nawigację, sprawdź odnośniki względne, obsługę błędów i widok telefonu. SFTP może służyć do przesyłania plików do hostingu.

```text
index.html → css/style.css
index.html → img/logo.png
```

**Pułapka**

Plik Logo.png i logo.png mogą być różnymi nazwami na serwerze.

**Sprawdź się**

Rozpoznaj przyczynę, gdy lokalnie obraz się ładuje, a na serwerze masz 404.

## Podstawy informatyki i praca zawodowa

Zakres efektów INF.03: 03.1, 03.2, 03.6, 03.7, 03.8.

**Po tym module**

Rozwiąż przekrojowy test z tematami pomocniczymi i wyjaśnij wskazane błędy.

### Systemy liczbowe i jednostki

***Uzupełnienie***

Cyfry w systemie pozycyjnym mnoży się przez kolejne potęgi podstawy. Bajt ma osiem bitów. KiB to 1024 bajty.

```text
1011₂ = 1×8 + 0×4 + 1×2 + 1×1 = 11₁₀
FF₁₆ = 15×16 + 15 = 255₁₀
```

**Pułapka**

Mb/s opisuje megabity na sekundę, MB to megabajty.

**Sprawdź się**

Przelicz 101010₂ na dziesiętny i szesnastkowy.

### Kodowanie, sprzęt i systemy

***Uzupełnienie***

UTF-8 zapisuje znaki Unicode za pomocą od jednego do czterech bajtów. RAM to pamięć robocza, SSD przechowuje dane po odłączeniu zasilania.

```text
ę → znak Unicode → bajty UTF-8
```

**Pułapka**

Zgodność kodowania pliku, odpowiedzi i połączenia z bazą pomaga zachować polskie litery.

**Sprawdź się**

Ustal, które elementy sprawdzisz przy uszkodzonych polskich znakach.

### Sieć i HTTP

***Uzupełnienie***

DNS rozwiązuje nazwy domen. HTTP opisuje wymianę żądań i odpowiedzi. HTTPS chroni transmisję. Status 404 oznacza brak żądanego zasobu.

```text
GET /img/logo.png → 404 Not Found
GET /style.css → 200 OK
```

**Pułapka**

Błędy 4xx zgłasza się w związku z żądaniem, a 5xx w związku z obsługą po stronie serwera.

**Sprawdź się**

Odróżnij problem z adresem zasobu od problemu uruchomienia PHP.

### Kopie, uprawnienia i dane

***Uzupełnienie***

Stosuj konkretne uprawnienia do zadania. Weryfikuj możliwość odtworzenia kopii. Używaj autorskich danych testowych w publicznych projektach.

```text
konto raportu → SELECT
konto edycji → uprawnienia stosowne do operacji
```

**Pułapka**

Eksport bez próbnego odtworzenia nie dowodzi, że odzyskasz dane.

**Sprawdź się**

Jakie prawo wystarczy kontu do odczytania raportu?

### BHP i ergonomia

***Uzupełnienie***

Zorganizuj stanowisko tak, by ograniczyć obciążenie wzroku i ciała. Przy zagrożeniu zabezpiecz miejsce i zgłoś je odpowiedniej osobie.

```text
monitory bez odbić • podparte stopy • regularna zmiana pozycji
```

**Pułapka**

BHP obejmuje też przewody, drogi ewakuacji i stan wyposażenia.

**Sprawdź się**

Wskaż trzy uchybienia na przykładowym stanowisku komputerowym.

### Angielski techniczny

***Uzupełnienie***

Rozpoznawaj polecenia w dokumentacji i komunikatach. Dobieraj znaczenie do kontekstu programu.

```text
required field → pole wymagane
foreign key → klucz obcy
query returned no rows → zapytanie nie zwróciło wierszy
```

**Pułapka**

Library w kontekście kodu oznacza bibliotekę.

**Sprawdź się**

Zinterpretuj „undefined variable” i „permission denied”.

### Praca w zespole, etyka i dokumentacja

***Uzupełnienie***

Rozpisz zadania z kryteriami odbioru. Zgłoszenie błędu powinno zawierać kroki, wynik oczekiwany i rzeczywisty. Dokumentuj sposób uruchomienia.

```text
1. Otwórz kalkulator.
2. Wpisz 0.
Oczekiwane: komunikat. Rzeczywiste: 0 zł.
```

**Pułapka**

Samo „nie działa” utrudnia odtworzenie usterki.

**Sprawdź się**

Napisz krótkie zgłoszenie z krokiem, środowiskiem i wynikiem.

## Projekty i próby egzaminacyjne

Zakres efektów INF.03: 03.3, 03.4, 03.5.

**Po tym module**

Wykonaj jedną próbę PHP+SQL i jedną JS+SQL z zegarem. Porównaj pliki z kryteriami i popraw dwie najsłabsze rzeczy.

### Projekt PHP i SQL

***Priorytet egzaminacyjny***

Po imporcie zaplanuj tabele oraz kwerendy. W PHP uruchom połączenie, odczyt i generowanie HTML, a dopiero potem przejdź ścieżkę odbioru.

```text
baza → kwerendy i dowody → HTML/CSS → mysqli → przeglądarka
```

**Pułapka**

Oddziel działające w bazie zapytanie od błędu w renderowaniu.

**Sprawdź się**

Wykonaj próbę „Rowerem po mieście” i sprawdź scenariusz braku danych.

### Projekt JavaScript i SQL

***Priorytet egzaminacyjny***

Jeśli polecenie przewiduje osobne rezultaty, zapisz kwerendy w pliku i zrzuty oddzielnie. Skrypt kliencki przygotuj według podanych danych i zachowania.

```text
SQL w phpMyAdmin → pliki i zrzuty
HTML/CSS/JS → interfejs i działanie w przeglądarce
```

**Pułapka**

W arkuszu mogą się pojawić PHP i JavaScript jednocześnie. Przeczytaj każdy podpunkt.

**Sprawdź się**

Wybierz archiwalny wariant JS+SQL i odtwórz go w 150 minut.

### Próba odbioru i samoocena

***Priorytet egzaminacyjny***

Sprawdzaj punkty po ukończeniu etapów. Otwórz finalny katalog w docelowym środowisku i wykonaj scenariusze z polecenia.

```text
nazwy i ścieżki → import → zapytania → skrypty → zrzuty → plik z nazwą przeglądarki
```

**Pułapka**

Ocena według klucza weryfikuje konkretne rezultaty arkusza.

**Sprawdź się**

Rozpisz punkty z klucza na wykonane, częściowe i pominięte.

## Źródła

Oficjalne wymagania i przykłady zadań. [Informator CKE](https://bip.cke.gov.pl/attachments/download/8580) · [Podstawa programowa](https://eli.gov.pl/api/acts/DU/2019/991/text/I/D20190991-08.pdf)

Specyfikacje i dokumentacja. [HTML WHATWG](https://html.spec.whatwg.org/) · [Selektory W3C](https://www.w3.org/TR/selectors-4/) · [JavaScript TC39](https://tc39.es/ecma262/) · [PHP](https://www.php.net/manual/en/) · [MariaDB](https://mariadb.com/docs/server/reference/sql-statements/data-manipulation/selecting-data/select)
