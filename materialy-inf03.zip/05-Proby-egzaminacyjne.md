# INF.03 Dwie próby praktyczne

Ustaw zegar na 150 minut. Czytaj sekcje w kolejności i zapisuj zrzuty po wykonaniu kolejnych poleceń. Klucz na końcu służy do sprawdzenia już oddanych plików.

## Próbny egzamin / Rowerem po mieście

Masz 150 minut. Zbuduj lokalny katalog miejskiej wypożyczalni rowerów w PHP, MariaDB/MySQL, HTML, CSS i JavaScripcie. Korzystaj z lokalnego Apache i MySQL w XAMPP lub równoważnego zestawu. Zaimportuj bazę z rowery.sql. Czasy w sekcjach to orientacyjny podział pracy.

**Baza do importu** `rowery.sql`

### Przygotowanie i SQL · 35 min

- [ ] Utwórz folder rowery w katalogu witryn lokalnego Apache. Zaimportuj plik rowery.sql do pustej bazy inf03_rowery. Baza ma 3 typy i 5 rowerów. Kolumna typ_id w tabeli rowery wskazuje id w tabeli typy. Zapisz zrzut całego ekranu pokazujący obie tabele jako import.png.
- [ ] Zapisz cztery ponumerowane zapytania w kwerendy.txt. Zapytanie 1 ma zwracać nazwę i stawkę dostępnych rowerów, rosnąco po stawce. Przed aktualizacją oczekiwane wiersze to Rondo (11,00), Aleja (12,50) i Most (15,00).
- [ ] Zapytanie 2 ma zwracać nazwy wszystkich rowerów i odpowiadających im typów, w kolejności rosnącej według nazwy roweru. Wynik ma mieć 5 wierszy.
- [ ] Zapytanie 3 ma zwracać każdy typ oraz liczbę dostępnych rowerów tego typu. Malejąco po liczbie oczekiwane wyniki to Miejski 2, Trekkingowy 1, Górski 0.
- [ ] Zapytanie 4 ma zmienić stawkę roweru o id równym 4 na 17,50 zł i zachować pozostałe wiersze.
- [ ] Uruchom każde zapytanie i zachowaj widoczny wynik jako q1.png, q2.png, q3.png i q4.png. W przypadku aktualizacji pokaż komunikat o zmianie lub kontrolny SELECT dla id = 4.

### Grafika i HTML · 30 min

- [ ] Przygotuj ikonę kierunkową jako plik ikona.png o wymiarach 256 × 256 px. Umieść zieloną strzałkę na przezroczystym tle i zostaw co najmniej 24 px marginesu wokół niej.
- [ ] Utwórz index.php z językiem polskim, kodowaniem UTF-8 i tytułem „Rowerem po mieście”. Dodaj metadane viewport i odwołanie do zewnętrznego style.css.
- [ ] W nagłówku umieść ikonę z tekstem alternatywnym „Strzałka kierunkowa” i nagłówek h1 „Rowerem po mieście”. Nawigacja ma zawierać odnośniki „Rowery” i „Kalkulator” do odpowiednich sekcji na tej stronie.
- [ ] Utwórz sekcję „Dostępne rowery” z tabelą o kolumnach „Model”, „Typ” i „Stawka za godzinę”. Obok dodaj sekcję „Kalkulator” z polami „Rower” i „Liczba godzin”, przyciskiem „Oblicz” oraz miejscem na wynik. W stopce wpisz „Wypożyczalnia miejska”.

### CSS · 25 min

- [ ] Ustaw tło strony na #F1F5F9 i tekst na #0F172A. Użyj czcionki bezszeryfowej. Nagłówek i stopkę wyróżnij tłem #14532D oraz białym tekstem.
- [ ] Ustaw odległość 24 px między sekcjami. Powyżej 700 px pokaż tabelę i kalkulator obok siebie w proporcji 2:1. Do 700 px ułóż sekcje w jednej kolumnie.
- [ ] Nadaj tabeli szerokość 100%, połącz jej obramowania i zastosuj tło #DCFCE7 dla parzystych wierszy danych. Dodaj widoczne wyróżnienie fokusu klawiatury dla odnośników i pól.

### PHP i JavaScript · 45 min

- [ ] Połącz się z bazą inf03_rowery przez mysqli i ustaw kodowanie utf8mb4. Wybierz dostępne rowery z nazwami ich typów i uporządkuj je alfabetycznie według nazw rowerów.
- [ ] Za pomocą wyniku zapytania wypełnij tabelę i listę „Rower” w kalkulatorze. Każda pozycja listy powinna mieć identyfikator roweru jako value, nazwę jako tekst oraz stawkę liczbową jako data-stawka. Nazwy wyświetlaj bezpiecznie w HTML. Stawkę w tabeli podaj w zł z dwiema cyframi po przecinku.
- [ ] Dodaj zewnętrzny skrypt app.js. Po kliknięciu „Oblicz” pobierz stawkę wybranego roweru i pomnóż przez liczbę godzin. Od 4 godzin odejmij 10% od łącznej ceny. Pokaż wynik w formacie walutowym.
- [ ] Dla pustego pola, wartości ułamkowej i liczby spoza 1–8 pokaż „Podaj od 1 do 8 pełnych godzin.”. Ustaw początkowo 1 godzinę.

### Oddanie pracy · 15 min

- [ ] Sprawdź, czy katalog wyświetla Aleja, Most i Rondo, a Szlak oraz Szczyt pozostają poza wynikami. Stawka roweru Most po wykonaniu UPDATE ma wynieść 17,50 zł.
- [ ] Wybierz Aleja i ustaw 4 godziny. Kalkulator powinien pokazać 45,00 zł. Następnie ustaw 1 godzinę, 8 godzin i 9 godzin. Dla Aleja oczekiwane są 12,50 zł, 90,00 zł i komunikat o błędzie.
- [ ] Sprawdź układ przy 700 px i 701 px. Przejdź klawiszem Tab przez nawigację, wybór roweru, liczbę godzin i przycisk. Otwórz ikonę na kontrastowym tle i sprawdź przezroczystość.
- [ ] Zapisz nazwę przeglądarki w pliku przegladarka.txt. Oddajesz index.php, style.css, app.js, ikona.png, kwerendy.txt, import.png, q1.png–q4.png i przegladarka.txt. Otwórz projekt jeszcze raz z adresu lokalnego serwera.

## Mapa tras weekendowych

Zbuduj stronę katalogującą trasy. Część bazy wykonaj w MariaDB/MySQL. Dane wyświetlane na stronie wpisz z zestawu podanego w poleceniu. Zdarzenia obsłuż w JavaScripcie.

**Baza do importu** `02-trasy.sql`

### Przygotowanie i zapytania · 40 min

- [ ] Zaimportuj 02-trasy.sql i zapisz zrzut widoku obu tabel jako import.png.
- [ ] Pierwsza kwerenda zwraca nazwa i km otwartych tras według dystansu malejąco.
- [ ] Druga kwerenda zwraca nazwy tras i poziomów, po id tras rosnąco.
- [ ] Trzecia kwerenda liczy otwarte trasy dla każdego poziomu, również dla poziomu bez otwartych tras. Sortuj po id poziomu.
- [ ] Czwarta kwerenda zmienia dystans trasy Park z 6 na 7 km. Zapisz zapytania w kwerendy.txt. Zrzuty pełnego ekranu zapisz jako kw1.png do kw4.png. Dla UPDATE pokaż kontrolny SELECT.

### Grafika i HTML · 35 min

- [ ] Przygotuj baner 900 × 300 px jako baner.jpg. Wykorzystaj własne zdjęcie lub autorską ilustrację. Zapisz rozmiar do 200 kB.
- [ ] Utwórz index.html, ustaw lang="pl", UTF-8 i tytuł „Mapa tras”. Podłącz zewnętrzny style.css oraz app.js z defer.
- [ ] Umieść h1 i baner z tekstem alt „Ilustracja tras weekendowych”. Dodaj nawigację do sekcji „Trasy” i „Kalkulator”.
- [ ] Dodaj podpisaną tabelę otwartych tras z kolumnami „Trasa”, „Dystans”, „Poziom”. Użyj kolejności Łąka (4 km, Łatwa), Park (7 km, Łatwa), Rzeka (9 km, Średnia).
- [ ] Zbuduj kalkulator z listą tras, polem na tempo w km/h, polem wyboru postoju, przyciskiem „Oblicz” i obszarem wyniku. Powiąż etykiety z polami.

### CSS · 25 min

- [ ] Ustaw tło nagłówka i stopki #153245 z jasnym tekstem. W sekcji z tabelą scal obramowania i zaznacz nieparzyste wiersze danych kolorem #E3F0F3.
- [ ] Na ekranie szerszym niż 720 px pokaż tabelę i kalkulator w proporcji 2:1. Przy 720 px i mniej ustaw jedną kolumnę.
- [ ] Zapewnij skalowanie banera z zachowaniem proporcji i wyraźne wyróżnienie fokusu.

### Skrypt · 35 min

- [ ] Wartość opcji określa dystans całkowity trasy. Pole tempa przyjmuje liczbę od 1 do 20 km/h włącznie, w tym ułamki. Przy pustym polu lub błędnym tempie wypisz „Wpisz tempo od 1 do 20 km/h.”
- [ ] Po kliknięciu policz czas w minutach: 60 × dystans / tempo. Przy zaznaczonym postoju dodaj 15 minut. Zaokrąglij na końcu do pełnych minut i wyświetl „Szacowany czas: X min”.
- [ ] Sprawdź, czy zmiana trasy, tempa i postoju wpływa na wynik. Pole wejściowe i wynik pozostają dostępne z klawiatury.

### Kontrola i oddanie · 15 min

- [ ] Dla Parku przy tempie 4 z postojem pokaż 120 min. Dla Łąki przy tempie 2,5 bez postoju pokaż 96 min. Dla pustego pola i liczby 0 pokaż komunikat.
- [ ] Oddaj index.html, style.css, app.js, baner.jpg, import.png, kwerendy.txt, kw1.png–kw4.png oraz przegladarka.txt z nazwą przeglądarki.

## Klucz samooceny

### Próbny egzamin / Rowerem po mieście

```sql
SELECT nazwa, stawka FROM rowery WHERE dostepny = 1 ORDER BY stawka ASC;

SELECT r.nazwa AS rower, t.nazwa AS typ FROM rowery AS r INNER JOIN typy AS t ON r.typ_id = t.id ORDER BY r.nazwa ASC;

SELECT t.nazwa, COUNT(r.id) AS liczba FROM typy AS t LEFT JOIN rowery AS r ON r.typ_id = t.id AND r.dostepny = 1 GROUP BY t.id, t.nazwa ORDER BY liczba DESC;

UPDATE rowery SET stawka = 17.50 WHERE id = 4;
```

- Po aktualizacji katalog zawiera Aleja, Most i Rondo. Stawka Most to 17,50 zł.
- Dla 4 godzin roweru Aleja wynik to 45,00 zł. Dla 9 godzin widoczny jest komunikat błędu.
- Ikona 256 × 256 px zachowuje przezroczystość.

### Mapa tras weekendowych

```sql
SELECT nazwa, km FROM trasy WHERE otwarta = 1 ORDER BY km DESC;

SELECT t.nazwa AS trasa, p.nazwa AS poziom FROM trasy AS t INNER JOIN poziomy AS p ON t.poziom_id = p.id ORDER BY t.id;

SELECT p.nazwa, COUNT(t.id) AS liczba FROM poziomy AS p LEFT JOIN trasy AS t ON t.poziom_id = p.id AND t.otwarta = 1 GROUP BY p.id, p.nazwa ORDER BY p.id;

UPDATE trasy SET km = 7 WHERE id = 2;
```

- Przed aktualizacją kwerenda 1 zwraca Rzeka 9, Park 6, Łąka 4. Po aktualizacji Park ma 7 km.
- Kwerenda 2 zwraca pięć wierszy. Kwerenda 3 daje Łatwa 2, Średnia 1, Trudna 0.
- Dla 7 km przy 4 km/h z postojem wynik to 120 min. Dla 4 km przy 2,5 km/h bez postoju wynik to 96 min.
- Każde pole ma etykietę i działa po przejściu klawiszem Tab. Przy 720 px sekcje są w jednej kolumnie.
