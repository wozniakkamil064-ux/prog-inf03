# INF.03 od zera do próby egzaminacyjnej

Zacznij od zbudowania jednej działającej strony i naucz się dodawać do niej warstwy. HTML porządkuje treść. CSS nadaje układ. JavaScript reaguje na działania użytkownika. SQL pobiera i zmienia dane. PHP łączy formularz, bazę i HTML generowany na serwerze.

Na pisemnym masz 40 pytań i 60 minut. Próg to 20 poprawnych odpowiedzi. Na praktycznym INF.03 masz 150 minut, a próg to 75% punktów. Materiał praktyczny uwzględnia 94 publiczne arkusze SG z 11 sesji od czerwca 2021 do czerwca 2026. W tym zbiorze HTML i CSS wystąpiły w 94 arkuszach, SQL w 89, PHP było wymagane w 62, a JavaScript w 33. Jeden arkusz wymagał obu języków skryptowych. Zakres statystyk obejmuje publiczne warianty terminu głównego. [Zasady CKE](https://egzaminy.gov.pl/cke/tresc/o-egzaminie-egzamin-zawodowy-formula-2019) · [Informator technika programisty](https://bip.cke.gov.pl/attachments/download/8580) · [Archiwum arkuszy](https://mahlik.ucz.edu.pl/kursy/materialy/)

## Kolejność nauki

| Etap | Czego się uczysz | Co robisz samodzielnie |
| --- | --- | --- |
| 1. Środowisko | Pliki, ścieżki, localhost, Apache, PHP, baza, narzędzia przeglądarki | Uruchamiasz katalog projektu i poprawiasz błędne odwołanie do pliku. |
| 2. HTML | Szkielet UTF-8, semantyka, linki, listy, obrazy, tabele, formularze | Z pamięci budujesz cennik z kotwicą, tabelą i formularzem POST. |
| 3. CSS | Selektory, kaskada, odstępy, wymiary, kolory, Flexbox, Grid i breakpointy | Odtwarzasz układ z opisu, a potem sprawdzasz obie strony punktu przełączenia. |
| 4. SQL | Tabele i relacje, SELECT, WHERE, ORDER BY, JOIN, grupowanie, modyfikacje i import | Importujesz bazę. Zapisujesz i dokumentujesz cztery wyniki, w tym relację i kontrolowany UPDATE. |
| 5. JavaScript | Typy, warunki, pętle, tablice, funkcje, DOM, zdarzenia i walidacja | Tworzysz kalkulator lub galerię. Testujesz skrajne wartości i puste pole. |
| 6. PHP | Odczyt GET/POST, walidacja, mysqli, wyniki SQL i generowanie HTML | Budujesz listę z bazy, filtr z formularza i komunikat pustego wyniku. |
| 7. Grafika i CMS | Kadrowanie, skalowanie, przezroczystość, kompresja, formaty i typy hostingu | Oddajesz plik o zadanych wymiarach i sprawdzasz go w przeglądarce. |
| 8. Przygotowanie pisemne | Podstawy informatyki, HTTP, BHP, język zawodowy, dokumentacja i zespół | Wypełniasz próbę 40/60. Grupujesz błędy i rozwiązujesz po jednym nowym zestawie z najsłabszych działów. |
| 9. Praktyka egzaminacyjna | Przepływ pracy, pliki, zrzuty, czas i kryteria odbioru | Robisz próbę PHP+SQL i próbę JS+SQL. Po każdej oceniasz pliki i zachowania z kluczem. |

Grafikę możesz zacząć równolegle z HTML. Rozdział o podstawach informatyki rozłóż na krótkie bloki po zajęciach praktycznych. Kolejność etapów to ścieżka od zera i możesz pominąć rozdział, gdy umiesz wykonać wskazane zadanie samodzielnie.

## Najważniejsze do zapamiętania

- **HTML.** Szkielet dokumentu, zewnętrzny CSS i JS, semantyka układu, `href` i `id`, `src` i `alt`, `th` i `td`, `label for` oraz rozróżnienie `id` i `name` w formularzu.
- **CSS.** Selektory typu, klasy i identyfikatora, relacja dziecka z `>`, `:hover`, `:nth-child`, box model i przełączenie układu przez `@media`.
- **SQL.** Kolejność klauzul, `JOIN ... ON`, `WHERE` i `HAVING`, pusta grupa po `LEFT JOIN`, `COUNT(id)`, sortowanie i kontrola `WHERE` przed modyfikacją.
- **JavaScript.** Wartość pola jest tekstem. Konwersja po kontroli pustej wartości, warunek zakresu, indeks od zera, `addEventListener`, `textContent`, `classList` oraz granice warunku.
- **PHP.** Zgodność `name` z kluczem GET/POST, walidacja po stronie serwera, `mysqli`, `utf8mb4`, parametry i kodowanie tekstu do HTML.
- **Praktyka.** Zgodność nazw plików i zrzutów z arkuszem. Oddawaj sprawdzone rezultaty polecenia i otwórz projekt z właściwego katalogu.

W lekcjach **priorytet 1** oznacza umiejętność do samodzielnego wykonania. **Priorytet 2** obejmuje pojęcia do wyjaśnienia i zastosowania z krótkim przykładem. **Priorytet 3** występuje w katalogu HTML i ułatwia rozpoznanie mniej typowych elementów.

## Bloki pracy

Typowy blok powtórki może trwać 45–75 minut. Przeczytaj dwie lub trzy krótkie lekcje, odtwórz ich wzorzec z pamięci, rozwiąż trzy warianty i wróć do błędów. Przy kolejnym podejściu zmień rodzinę albo trudność. Własne błędy zapisuj jako pytania, np. „Dlaczego moja pusta grupa ma wynik 1?”.

Gdy zostało kilka dni, oprzyj powtórkę na pięciu blokach. Pierwszy poświęć dokumentowi HTML i CSS. Drugi kwerendom i zrzutom. Trzeci zdarzeniom JavaScript. Czwarty PHP i bazie. W piątym zrób pełną praktykę i sprawdź klucz. Jeśli poprawiasz wyłącznie pisemny, w każdym bloku połącz czytanie kodu z pytaniami, a finał zrób jako test 40/60.

## Jak będą działały ćwiczenia

Każde ćwiczenie ma stały identyfikator, poziom, dane wejściowe, polecenie, kod startowy, podpowiedź, rozwiązanie i sposób weryfikacji. Wariant zachowuje umiejętność, ale może zmienić wartości graniczne, kolejność sortowania, rekordy, układ, selektory lub parametry zadania. Wyszukiwanie rozwiązania po identyfikatorze odtwarza dokładnie te same dane.

- **JavaScript** sprawdzają przykłady wejścia i wyjścia oraz scenariusze zdarzeń w DOM. Uczeń może wyświetlić podpowiedź i porównać wynik.
- **SQL** sprawdza wiersze wyniku i wymagany porządek. Przy INSERT i UPDATE sprawdza pełny stan tabeli, w tym zachowanie pozostałych rekordów.
- **HTML i CSS** łączą podgląd z kryteriami, np. działającą kotwicą, sparowaną etykietą, wymiarem karty i układem na dwóch szerokościach.
- **PHP** w zestawie ma przypadki testowe do uruchomienia lokalnie. W zadaniach z bazą sprawdź rezultat w XAMPP lub podobnym środowisku. GitHub Pages może udostępnić kurs, podgląd front-endu i pliki do pobrania.
- **Grafika i pełne próby** mają checklisty efektu końcowego. Liczą się m.in. format, wymiary i pliki wskazane przez polecenie.

## Kształt nowej strony

Główny ekran pokazuje plan i ostatni przerabiany temat. Środek lekcji ma krótką regułę, przykład z podpisem, typowy błąd i polecenie do samodzielnego wykonania. Fiszki da się filtrować po języku. Słownik HTML będzie miał wyszukiwarkę po nazwie znacznika i widok priorytetu egzaminacyjnego.

Laboratorium łączy polecenie, edytor i wynik w jednym widoku. Na wąskim ekranie elementy układają się pionowo. W trudniejszych ćwiczeniach podpowiedź można rozwinąć osobno. Sekcja prób daje zegar, pliki startowe i klucz samooceny w oddzielnych krokach. Materiały do czytania pozostają dostępne bez uruchamiania edytora.

Punktem wyjścia do projektu wizualnego jest ciemny grafit, wysoki kontrast, stonowane przejścia kolorów i jasny akcent przy aktywnym kroku. Ruch służy zmianie widoku lub pokazaniu efektu kodu. Układ i detale stylistyczne zostaną dopasowane w drugim etapie do przesłanej zakładki.
