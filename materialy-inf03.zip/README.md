# Materiały INF.03

Zacznij od 00-Plan-nauki.md, a potem przejdź do lekcji. Słownik HTML, fiszki, pytania, przykładowe ćwiczenia i próby można otworzyć w zwykłym edytorze tekstu.

## Pliki do wykorzystania przy budowie strony

- materialy.json zawiera lekcje, katalog HTML, fiszki, pytania, próbne egzaminy, statystyki i źródła.

- cwiczenia.mjs wystawia eksporty katalog, scenariusze i zadanie. Każda rodzina ma po 16 zestawów danych w 16 scenariuszach.

- archiwum.json zawiera indeks 94 publicznych arkuszy SG z linkami do plików i kluczy.

- rowery.sql i 02-trasy.sql to bazy do dwóch prób praktycznych. Importuj do nowych baz ćwiczebnych.

Przykład wygenerowania zadania w Node.js. To samo API można wywołać z modułu przeglądarkowego.

```javascript
import { zadanie } from './cwiczenia.mjs';
console.log(zadanie('sql-grupy', 'wypozyczalnia', 3));
```

Pole verification zawiera wynik SQL, przypadki testowe JavaScript/PHP, scenariusz DOM albo listę kryteriów. Weryfikacja składni PHP i SQL w przyszłym interfejsie zależy od docelowego środowiska. Tego pliku używaj jako danych i materiałów do etapu budowy.
