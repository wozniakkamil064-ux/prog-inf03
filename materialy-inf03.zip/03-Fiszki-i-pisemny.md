# INF.03 Fiszki i pytania pisemne

Zakryj odpowiedź i spróbuj podać regułę z pamięci. Przy pytaniach testowych wybierz odpowiedź przed sprawdzeniem klucza na końcu.

## Fiszki

**HTML — Co umieszczasz w head na początku dokumentu?**

Kodowanie UTF-8, metadane viewportu, title i odwołania do zasobów. Doctype jest przed html.

**HTML — Co łączy label z polem, a co tworzy klucz wysłany do PHP?**

for odpowiada wartości id. Kluczem otrzymanym przez PHP jest name.

**HTML — Jak połączyć „Oferta” z sekcją na tej samej stronie?**

Wstaw href="#oferta" w a oraz id="oferta" w sekcji.

**HTML — Kiedy użyć pustego tekstu alternatywnego?**

Dla obrazu dekoracyjnego ustaw alt="" bez spacji. Dla informacyjnego opisz informacje widoczne na obrazie.

**HTML — Jak odróżnić nagłówek tabeli od komórki danych?**

th to nagłówek, td to wartość danych. scope wskazuje kolumnę lub wiersz.

**HTML — Jaki type dla przycisku obsługiwanego wyłącznie przez JS?**

type="button". W formularzu przycisk wysyłający ma type="submit".

**HTML — Jak podłączyć CSS i zewnętrzny JS?**

link rel="stylesheet" href="style.css" oraz script src="app.js" defer z zamknięciem script.

**CSS — Jak wybrać tylko bezpośrednie linki nav?**

Selektorem nav > a. Selektor nav a wybiera też zagnieżdżone linki.

**CSS — Jak zaznaczyć parzyste wiersze danych tabeli?**

tbody tr:nth-child(even).

**CSS — Co wlicza się do width przy box-sizing: border-box?**

Treść, padding i border. Margin pozostaje poza tym obrysem.

**CSS — Co wygra w tej samej warstwie kaskady, #wynik czy .wynik?**

#wynik ma większą specyficzność. Kolejność rozstrzyga remis specyficzności.

**CSS — Czym ustawić odstępy w Flexbox lub Grid?**

gap ustawia odstęp między elementami lub torami.

**CSS — Jak ułożyć proporcję 2:1 w Grid?**

grid-template-columns: 2fr 1fr przy display: grid.

**CSS — Jak przełączyć układ przy 700 px włącznie?**

@media (max-width: 700px) { ... }.

**SQL — Jaka jest podstawowa kolejność klauzul?**

SELECT, FROM z JOIN i ON, WHERE, GROUP BY, HAVING, ORDER BY, LIMIT.

**SQL — Co umieścić w ON dla tabeli rowery i typy?**

r.typ_id = t.id, jeśli typ_id jest kluczem obcym wskazującym id typu.

**SQL — Jak zachować grupę bez pasującego wiersza?**

Rozpocznij od tabeli grup i użyj LEFT JOIN. Warunki dotyczące dopasowania prawych rekordów umieść w ON.

**SQL — Jak policzyć dopasowania po LEFT JOIN?**

COUNT(p.id) liczy tylko niepuste wartości po stronie dopasowanych pozycji.

**SQL — Która klauzula filtruje po liczbie elementów grupy?**

HAVING, np. HAVING COUNT(*) >= 2. WHERE filtruje przed grupowaniem.

**SQL — Jak znaleźć brak wartości?**

IS NULL albo IS NOT NULL.

**SQL — Co zrobić przed UPDATE konkretnego rekordu?**

Uruchom kontrolny SELECT z tym samym WHERE. Potwierdź, że wskazuje zamierzony rekord.

**SQL — Jak uruchomić odczyt od najwyższej ceny z remisem po nazwie?**

ORDER BY cena DESC, nazwa ASC.

**JavaScript — Co daje "12" + 5 i jak otrzymać 17?**

Daje "125". Użyj Number("12") + 5.

**JavaScript — Czemu sprawdzić pusty tekst przed Number?**

Number("") zwraca 0, więc brak wartości może zostać pomylony z poprawnym zerem.

**JavaScript — O co pytasz Number.isInteger(n)?**

Czy n ma typ number i reprezentuje skończoną liczbę całkowitą.

**JavaScript — Jak brzmi ostatni poprawny indeks tablicy?**

tablica.length - 1, jeśli tablica ma elementy.

**JavaScript — Co dają filter i map?**

filter wybiera elementy, a map zwraca przekształconą wartość dla każdego wejściowego elementu.

**JavaScript — Jak wstawić wynik jako zwykły tekst?**

element.textContent = wynik.

**JavaScript — Jak podpiąć funkcję bez jej natychmiastowego wywołania?**

element.addEventListener("click", funkcja).

**JavaScript — Kiedy użyć preventDefault?**

Np. przy lokalnym przeliczaniu na submit, gdy formularz ma pozostać na tej samej stronie.

**PHP — W którym miejscu działa kod PHP?**

Na serwerze z interpreterem PHP. Przeglądarka otrzymuje wynik, zwykle HTML.

**PHP — Jaką operacją łączysz dwa teksty?**

Kropką, np. $nazwa . " zł".

**PHP — Jak odczytać nazwę wysłaną metodą POST?**

Z $_POST['nazwa'] lub filter_input(INPUT_POST, 'nazwa', ...), zgodnie z name kontrolki.

**PHP — Co wywołać po otwarciu połączenia mysqli?**

set_charset('utf8mb4'), aby ustawić kodowanie połączenia.

**PHP — Co robi fetch_assoc()?**

Pobiera kolejny rekord jako tablicę asocjacyjną, której klucze to nazwy kolumn lub aliasy.

**PHP — Jak przekazać wartość wpisaną przez użytkownika do SQL?**

prepare z ?, bind_param z typem i zmienną, a następnie execute.

**PHP — Jak wypisać wartość tekstową wewnątrz HTML?**

htmlspecialchars($tekst, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8').

**Grafika — Co różni kadrowanie od skalowania?**

Kadrowanie wybiera wycinek obrazu. Skalowanie zmienia jego wymiary w pikselach.

**Grafika — Którego formatu użyć do ikony rastrowej z przezroczystością?**

PNG z kanałem alfa, jeśli taki format przewiduje zadanie.

**Grafika — Czy zmiana rozszerzenia .jpg na .png zmienia format?**

Trzeba otworzyć plik i wyeksportować go jako PNG.

**Praktyka — Co zapisać zaraz po wykonaniu kwerendy?**

Wklej kwerendę do wymaganego pliku. Zachowaj zrzut wyniku zgodny z nazwą i formatem z polecenia.

**Praktyka — Jaki ma być ostatni test całego zadania?**

Otwórz gotowe pliki w docelowym środowisku. Sprawdź ekran, zdarzenia, dane i dokładne nazwy oddawanych plików.

## Pytania

### 1. Który element najlepiej opisuje blok odnośników do głównych podstron?

- A. &lt;aside&gt;
- B. &lt;nav&gt;
- C. &lt;footer&gt;
- D. &lt;address&gt;

### 2. Pole ma zapis &lt;input id="miasto" name="lokalizacja" value="Łódź"&gt;. Pod jaką nazwą formularz przekaże jego wartość?

- A. miasto
- B. Łódź
- C. input
- D. lokalizacja

### 3. W nagłówku tabeli komórka ma zająć trzy sąsiednie kolumny. Który zapis jest prawidłowy?

- A. &lt;th colspan="3"&gt;
- B. &lt;th rowspan="3"&gt;
- C. &lt;th cols="3"&gt;
- D. &lt;tr span="3"&gt;

### 4. Obrazek obok podpisu służy wyłącznie dekoracji. Jaki atrybut pomija go w typowym odczycie czytnika ekranowego?

- A. alt="dekoracja"
- B. title="dekoracja"
- C. alt=""
- D. src=""

### 5. Po co użyć &lt;pre&gt; w przykładzie kodu, w którym ważne są wcięcia?

- A. Ukrywa tekst w DOM
- B. Zachowuje spacje i nowe wiersze
- C. Kopiuje kod do schowka
- D. Uruchamia zawarty kod

### 6. Który zapis poprawnie dołączy plik styl.css do dokumentu?

- A. &lt;style src="styl.css"&gt;
- B. &lt;script href="styl.css"&gt;&lt;/script&gt;
- C. &lt;link src="styl.css"&gt;
- D. &lt;link rel="stylesheet" href="styl.css"&gt;

### 7. Który typ w MySQL najlepiej przechowa cenę 7,99 zł z dokładnością do grosza?

- A. DATE
- B. TINYINT
- C. DECIMAL(8,2)
- D. TEXT

### 8. Zapytanie ma zachować wszystkich klientów, nawet bez zamówień. Klienci są po lewej stronie złączenia. Którego złączenia użyjesz?

- A. INNER JOIN
- B. LEFT JOIN
- C. CROSS JOIN
- D. JOIN bez ON

### 9. Jak odfiltrować kategorie po grupowaniu tak, aby pokazać tylko te z co najmniej pięcioma rekordami?

- A. WHERE COUNT(*) &gt;= 5
- B. ORDER BY COUNT(*) &gt;= 5
- C. LIMIT COUNT(*) &gt;= 5
- D. HAVING COUNT(*) &gt;= 5

### 10. Który wzorzec oznacza nazwę zaczynającą się na M i mającą dokładnie 3 znaki?

- A. LIKE 'M__'
- B. LIKE 'M%'
- C. LIKE '%M__'
- D. LIKE '_M_'

### 11. Który warunek sprawdzi, czy pole data_odbioru nie ma wartości?

- A. data_odbioru = NULL
- B. data_odbioru IS NULL
- C. data_odbioru LIKE 'NULL'
- D. data_odbioru &lt;&gt; NULL

### 12. W tabeli jest 5 wierszy, a kolumna email w dwóch z nich ma wartość NULL. Ile zwróci COUNT(email)?

- A. 2
- B. 5
- C. 7
- D. 3

### 13. Klienci mają wiele zamówień, a każde zamówienie ma jednego klienta. Gdzie umieścisz klucz obcy?

- A. W obu tabelach jako obowiązkowe pole
- B. W klientach jako zamowienie_id
- C. W zamówieniach jako klient_id
- D. W osobnej kopii tabeli klientów

### 14. Którym poleceniem zmienisz szerokość kolumny z VARCHAR(20) na VARCHAR(60) w MySQL?

- A. ALTER TABLE
- B. UPDATE
- C. INSERT INTO
- D. SELECT DISTINCT

### 15. Rozpocząłeś transakcję w InnoDB i zmieniłeś wiersze. Co wycofa zmiany przed ich zatwierdzeniem?

- A. COMMIT
- B. ROLLBACK
- C. GRANT
- D. GROUP BY

### 16. Co zwróci wyrażenie "4" + 3 w JavaScript?

- A. 7
- B. NaN
- C. "7"
- D. "43"

### 17. Ile razy wykona się ciało pętli for (let i = 2; i &lt;= 8; i += 3)?

- A. 2
- B. 3
- C. 6
- D. 7

### 18. Jak odczytasz zawartość pola tekstowego o id="miasto"?

- A. document.querySelector('#miasto').value
- B. document.querySelector('miasto').innerHTML
- C. document.getElementById('#miasto').value
- D. document.getElementById('miasto').textContent

### 19. Jakie zdarzenie obsłużysz na formularzu, żeby reagować zarówno na przycisk wysłania, jak i Enter?

- A. input
- B. mouseover
- C. submit
- D. blur

### 20. Dla jakich wartości x warunek x &gt; 2 &amp;&amp; x &lt; 5 będzie prawdziwy?

- A. Dla każdej liczby od 2 do 5 włącznie
- B. Tylko dla liczb większych od 5
- C. Dla x równego 2 lub 5
- D. Dla liczb ściśle pomiędzy 2 a 5

### 21. Co pokaże console.log([10, 20, 30][1])?

- A. 10
- B. 20
- C. 30
- D. undefined

### 22. Wynik ma pokazać dosłownie wpisane przez użytkownika znaki &lt; i &gt;. Której właściwości użyjesz?

- A. textContent
- B. innerHTML
- C. outerHTML
- D. style

### 23. Który selektor dotyczy tylko linków będących bezpośrednimi dziećmi elementu o klasie menu?

- A. #menu a
- B. .menu a
- C. .menu &gt; a
- D. a.menu

### 24. Element używa content-box. Ma width: 160px, padding: 12px, border: 2px solid. Ile wynosi szerokość razem z obramowaniem?

- A. 174 px
- B. 188 px
- C. 160 px
- D. 184 px

### 25. Co oznacza padding: 8px 20px?

- A. Góra i dół po 8 px, lewa i prawa po 20 px
- B. Góra i dół po 20 px, lewa i prawa po 8 px
- C. Góra 8 px, reszta po 20 px
- D. Dół 8 px, reszta po 20 px

### 26. Który zapis ustawia kolor tła wiersza tabeli pod kursorem?

- A. tr::hover { color: gray; }
- B. table &gt; hover { background: gray; }
- C. tr:hover { color: gray; }
- D. tr:hover { background-color: gray; }

### 27. Jaki sześciocyfrowy zapis koloru odpowiada skrótowi #4a7?

- A. #040a07
- B. #407a47
- C. #44aa77
- D. #4a74a7

### 28. W kontenerze flex o domyślnym flex-direction: row co zwykle wyśrodkuje dzieci w pionie?

- A. align-items: center
- B. justify-content: center
- C. text-align: center
- D. display: inline

### 29. Co zwróci w PHP wyrażenie "INF" . 3?

- A. "INF3"
- B. Błąd składni
- C. 3
- D. "INF.3"

### 30. Formularz ma method="post" oraz &lt;input name="sztuki"&gt;. Gdzie PHP odczyta wartość?

- A. $_GET['sztuki']
- B. $_SESSION['sztuki']
- C. $_POST['sztuki']
- D. $_COOKIE['sztuki']

### 31. Która funkcja odczyta kolejny rekord SELECT jako tablicę z nazwami kolumn?

- A. mysqli_connect
- B. mysqli_fetch_assoc
- C. mysqli_close
- D. mysqli_num_rows

### 32. Co zwróci trim("  kod testowy  ")?

- A. "kodtestowy"
- B. "  kod testowy"
- C. "kod testowy  "
- D. "kod testowy"

### 33. Jak przekazać do zapytania SQL numer wpisany przez użytkownika?

- A. Wpisać numer w nazwę tabeli
- B. Złożyć tekst zapytania przez doklejenie wartości
- C. Użyć parametru w przygotowanym zapytaniu
- D. Zastąpić WHERE instrukcją echo

### 34. Gdzie umieścisz stan zalogowania, który PHP ma zachować na serwerze między żądaniami?

- A. W $_SESSION po session_start()
- B. W $_GET
- C. W $_POST
- D. W lokalnej zmiennej $stan

### 35. Jak pobierzesz cenę z tablicy $dane = ["cena" =&gt; 18.50, "stan" =&gt; 4]?

- A. $dane.cena
- B. $dane[0]
- C. $dane-&gt;cena
- D. $dane["cena"]

### 36. Jaki format wybierzesz dla piktogramu złożonego z linii, który ma zachować ostrość przy dowolnym powiększeniu?

- A. JPEG
- B. BMP
- C. SVG
- D. MP3

### 37. Chcesz zachować półprzezroczyste tło grafiki rastrowej i zapisać piksele bezstratnie. Który format to umożliwia?

- A. PNG
- B. JPEG
- C. MP3
- D. CSV

### 38. Zdjęcie ma 1200 × 800 px. Który rozmiar po zmniejszeniu zachowa jego proporcje?

- A. 600 × 600 px
- B. 600 × 500 px
- C. 300 × 300 px
- D. 600 × 400 px

### 39. Jak nazywa się operacja usuwająca zbędne fragmenty przy krawędzi zdjęcia?

- A. Kwantyzacja
- B. Kadrowanie
- C. Odbicie
- D. Kompresja

### 40. Co w typowym CMS zmienia szablon wyglądu wielu podstron?

- A. Konto użytkownika
- B. Kopia bazy
- C. Motyw
- D. Rekord DNS

### 41. Ile różnych wartości może przyjąć piksel obrazu o głębi 5 bitów na piksel?

- A. 5
- B. 32
- C. 25
- D. 10

### 42. Ile wynosi 10110₂ w systemie dziesiętnym?

- A. 18
- B. 22
- C. 26
- D. 32

### 43. Która wartość w bajtach jest równa 2 KiB?

- A. 2000
- B. 1000
- C. 1024
- D. 2048

### 44. Jaka usługa pozwala odnaleźć adres IP na podstawie nazwy domeny?

- A. DNS
- B. SMTP
- C. HTML
- D. CMYK

### 45. Ktoś wysyła wiadomość naśladującą szkolny portal i prosi o wpisanie danych na obcej stronie. Jak nazywa się takie zagrożenie?

- A. Kompresja
- B. Pobieranie asynchroniczne
- C. Phishing
- D. Walidacja

### 46. Który kod odpowiedzi HTTP typowo oznacza, że pod adresem nie odnaleziono zasobu?

- A. 200
- B. 404
- C. 302
- D. 101

### 47. W przejściu obok biurek leżą przewody, o które ktoś może się potknąć. Co zrobisz w pierwszej kolejności?

- A. Podniosę jasność monitora
- B. Otworzę okno
- C. Zapiszę pliki do chmury
- D. Zabezpieczę miejsce i zgłoszę zagrożenie zgodnie z procedurą

### 48. Co oznacza polecenie Restore the database from a backup?

- A. Przywróć bazę z kopii zapasowej
- B. Nadaj uprawnienia do bazy
- C. Zmień nazwę bazy
- D. Wyeksportuj samą tabelę

### 49. Jak najczytelniej zgłosić błąd, który pojawia się przy wysłaniu formularza?

- A. Podać nazwę działu i wyrazić niezadowolenie
- B. Napisać tylko „zepsute”
- C. Podać kroki, oczekiwany wynik i faktyczny wynik
- D. Wysłać samą datę zdarzenia

### 50. Przed rozdzieleniem zadań ustalono, że publikacja zależy od testów. W jakiej kolejności je zaplanować?

- A. Publikacja, potem testy
- B. Testy, potem publikacja
- C. Zadania zawsze wykonywać równocześnie
- D. Najpierw opublikować sam harmonogram

## Odpowiedzi

**1. B.** nav oznacza sekcję przeznaczoną przede wszystkim do nawigacji.

**2. D.** Pole name określa nazwę parametru. Identyfikator id służy m.in. do powiązania pola z etykietą.

**3. A.** colspan określa liczbę kolumn zajmowanych przez komórkę.

**4. C.** Pusty tekst alternatywny mówi technologiom asystującym, że grafika pełni funkcję dekoracyjną.

**5. B.** Element pre domyślnie zachowuje białe znaki. Kod wewnątrz można dodatkowo oznaczyć przez code.

**6. D.** rel="stylesheet" określa typ zasobu, a href wskazuje jego adres.

**7. C.** DECIMAL przechowuje wartości dziesiętne o ustalonej precyzji i skali.

**8. B.** LEFT JOIN zachowuje wiersze z lewej tabeli. Przy braku pary z prawej strony zwraca NULL.

**9. D.** HAVING umożliwia zapisanie warunku na wyniku funkcji agregującej.

**10. A.** Każdy znak _ odpowiada dokładnie jednemu znakowi, więc M__ ma łącznie trzy pozycje.

**11. B.** Do porównania z NULL używa się IS NULL lub IS NOT NULL.

**12. D.** COUNT(kolumna) liczy wartości różne od NULL. W tym przykładzie 5 − 2 = 3.

**13. C.** Zamówienia są stroną wiele i przechowują identyfikator klienta.

**14. A.** ALTER TABLE zmienia strukturę tabeli, w tym definicję kolumny.

**15. B.** ROLLBACK wycofuje niezatwierdzone zmiany w transakcji.

**16. D.** Przy dodawaniu napisu operator + łączy teksty. Liczba 3 zostaje zamieniona na napis.

**17. B.** Kolejne wartości i to 2, 5 oraz 8. Następna wartość 11 nie spełni warunku.

**18. A.** querySelector przyjmuje selektor CSS, a wartość kontrolki jest we właściwości value.

**19. C.** submit opisuje próbę wysłania formularza niezależnie od sposobu jej wywołania.

**20. D.** &amp;&amp; wymaga spełnienia obu warunków, a ostre nierówności wykluczają granice.

**21. B.** Indeksowanie zaczyna się od zera. Indeks 1 oznacza drugi element.

**22. A.** textContent wstawia ciąg jako tekst bez interpretacji znaczników.

**23. C.** Kropka oznacza klasę, a &gt; ogranicza dopasowanie do bezpośredniego dziecka.

**24. B.** Szerokość to 160 + 2 × 12 + 2 × 2 = 188 px. Margines pozostaje poza obramowaniem.

**25. A.** Pierwsza wartość jest pionowa, druga pozioma.

**26. D.** :hover wybiera stan wskazania, a background-color ustawia kolor tła.

**27. C.** Każda cyfra zapisu skróconego jest powtórzona w swoim kanale koloru.

**28. A.** Przy kierunku row oś poprzeczna jest pionowa w standardowym poziomym trybie pisma.

**29. A.** Operator . łączy napisy. Liczba 3 zostaje zapisana jako część tekstu.

**30. C.** Dane typowego formularza przesłanego metodą POST trafiają do tablicy $_POST.

**31. B.** mysqli_fetch_assoc zwraca rekord w postaci tablicy asocjacyjnej.

**32. D.** trim usuwa białe znaki z obu końców. Spacja w środku zostaje.

**33. C.** Parametr przekazuje wartość oddzielnie od składni zapytania.

**34. A.** Sesja przechowuje dane między żądaniami. Przeglądarka zwykle dostarcza identyfikator sesji w ciasteczku.

**35. D.** Nawiasy kwadratowe pobierają element tablicy po kluczu. Tablica używa tu klucza tekstowego cena.

**36. C.** SVG przechowuje kształty w postaci wektorowej.

**37. A.** PNG umożliwia bezstratny zapis obrazu i przechowanie kanału alfa.

**38. D.** Zmniejszenie obu wymiarów o połowę zachowuje proporcje 3:2.

**39. B.** Kadrowanie pozostawia tylko wybrany fragment obrazu.

**40. C.** Motyw definiuje szablony i wygląd treści.

**41. B.** Pięć bitów pozwala zapisać 2⁵ = 32 kombinacje.

**42. B.** Wagi kolejnych ustawionych bitów wynoszą 16, 4 i 2. Ich suma to 22.

**43. D.** KiB używa podstawy 1024. Dwa kibibajty to 2 × 1024 B.

**44. A.** DNS publikuje rekordy nazw. Przykładowo rekord A wiąże nazwę z adresem IPv4.

**45. C.** Podszywanie się pod zaufaną instytucję dla wyłudzenia danych to phishing.

**46. B.** Kod 404 oznacza, że serwer nie odnalazł wskazanego zasobu.

**47. D.** Luźne przewody stwarzają bezpośrednie ryzyko potknięcia. Trzeba zabezpieczyć miejsce i usunąć przyczynę.

**48. A.** Restore to przywrócenie danych, a backup to kopia zapasowa.

**49. C.** Kroki i opis różnicy pozwalają odtworzyć problem i sprawdzić poprawkę.

**50. B.** Testy dostarczają wynik potrzebny przed publikacją. Zaplanuj najpierw zadanie, od którego zależy kolejne.
