# Słownik elementów HTML do INF.03

Katalog obejmuje 115 nazwanych elementów z indeksu WHATWG, w tym osadzane svg i math. Każda pozycja pokazuje zastosowanie i mały fragment. Elementy definiowane przez autora mają własne nazwy i nie tworzą zamkniętej listy. [Indeks elementów WHATWG](https://html.spec.whatwg.org/multipage/indices.html#elements-3)

## Zapis i atrybuty

- Deklaracja `<!doctype html>` poprzedza element html. Komentarz zapisujesz jako `<!-- treść -->`.

- Najczęstsze elementy puste to area, base, br, col, embed, hr, img, input, link, meta, source, track i wbr. W składni HTML nie zapisuje się dla nich znaczników zamykających.

- Identyfikatory i klasy służą do odwołań. `hidden` ukrywa element. `data-*` pozwala dodać własne dane. `aria-label` może nadać nazwę dostępną, gdy kontrolka jej potrzebuje.

- Formaty pól: text, email, number, password, date, search, tel, url, range, radio, checkbox, file i hidden. Dobierz wymagane ograniczenia, np. required, min, max i step.

- Wartości required, checked, disabled, readonly i multiple działają przez samą obecność atrybutu. Wyłączona kontrolka disabled nie jest przesyłana w formularzu. Pole readonly zwykle jest przesyłane.

- Dla elementów z własną nazwą użyj składni np. `<inf-karta></inf-karta>`. Takie komponenty są tematem rozszerzającym.

## Dokument

### html

Priorytet egzaminacyjny. Korzeń dokumentu. Atrybut lang wybiera język tekstu i pomaga czytnikom ekranu.

```html
<html lang="pl">…</html>
```

### head

Priorytet egzaminacyjny. Zawiera metadane i odwołania do zasobów. Treść widoczna na stronie trafia do body.

```html
<head><title>Sklep</title></head>
```

### body

Priorytet egzaminacyjny. Zawiera treść dokumentu i interfejs użytkownika.

```html
<body><main>Treść</main></body>
```

### title

Priorytet egzaminacyjny. Ustawia nazwę dokumentu wyświetlaną m.in. w zakładce przeglądarki.

```html
<title>Galeria rowerów</title>
```

### meta

Priorytet egzaminacyjny. Dodaje metadane, takie jak kodowanie znaków lub konfiguracja viewportu.

```html
<meta charset="utf-8">
```

### link

Priorytet egzaminacyjny. Deklaruje relację z zewnętrznym zasobem, np. arkuszem stylów.

```html
<link rel="stylesheet" href="style.css">
```

### style

Priorytet egzaminacyjny. Zawiera wewnętrzny arkusz CSS. Umieść go w head, gdy polecenie dopuszcza styl wewnętrzny.

```html
<style>p { color: navy; }</style>
```

### base

Rozpoznaj w dokumentacji. Ustala bazę adresów względnych w dokumencie. Występuje najwyżej jeden element base.

```html
<base href="https://example.org/katalog/">
```

### script

Priorytet egzaminacyjny. Osadza lub wczytuje JavaScript. defer przy zewnętrznym klasycznym skrypcie odkłada wykonanie do zakończenia parsowania HTML.

```html
<script src="app.js" defer></script>
```

### noscript

Uzupełnienie. Wyświetla treść zastępczą w przeglądarce z wyłączoną obsługą skryptów.

```html
<noscript>Włącz JavaScript, aby użyć kalkulatora.</noscript>
```

## Układ

### header

Priorytet egzaminacyjny. Nagłówek strony lub sekcji. Może zawierać logo, nazwę i nawigację.

```html
<header><h1>Atlas drzew</h1></header>
```

### nav

Priorytet egzaminacyjny. Sekcja głównych odnośników nawigacyjnych.

```html
<nav><a href="#galeria">Galeria</a></nav>
```

### main

Priorytet egzaminacyjny. Wyznacza główną, unikatową treść strony. W prostym dokumencie użyj jednego widocznego main.

```html
<main><h1>Cennik</h1></main>
```

### section

Priorytet egzaminacyjny. Grupuje tematycznie powiązaną treść, zwykle opisaną nagłówkiem.

```html
<section id="kontakt"><h2>Kontakt</h2></section>
```

### article

Priorytet egzaminacyjny. Samodzielna jednostka treści, np. wiadomość, oferta albo wpis.

```html
<article><h2>Nowa trasa</h2><p>Opis</p></article>
```

### aside

Priorytet egzaminacyjny. Treść poboczna powiązana z głównym tematem, np. polecane trasy.

```html
<aside><h2>Podobne trasy</h2></aside>
```

### footer

Priorytet egzaminacyjny. Stopka strony albo sekcji. Może zawierać autorstwo i kontakt.

```html
<footer>Autor: Jan Kowalski</footer>
```

### address

Uzupełnienie. Dane kontaktowe dotyczące strony lub najbliższego artykułu.

```html
<address><a href="mailto:biuro@example.org">Biuro</a></address>
```

### search

Rozpoznaj w dokumentacji. Obszar kontrolek do wyszukiwania lub filtrowania treści.

```html
<search><form><label>Produkt <input name="q"></label></form></search>
```

### hgroup

Rozpoznaj w dokumentacji. Grupuje jeden nagłówek z akapitem zawierającym podtytuł lub opis.

```html
<hgroup><h1>Katalog</h1><p>Wiosna</p></hgroup>
```

### div

Priorytet egzaminacyjny. Neutralny kontener blokowy. Nadaje się do grupowania elementów na potrzeby stylów.

```html
<div class="karty">…</div>
```

## Tekst

### h1

Priorytet egzaminacyjny. Nagłówek pierwszego poziomu. W prostym zadaniu oznacza główny tytuł.

```html
<h1>Wypożyczalnia</h1>
```

### h2

Priorytet egzaminacyjny. Nagłówek drugiego poziomu, zwykle dla głównej sekcji.

```html
<h2>Oferta</h2>
```

### h3

Priorytet egzaminacyjny. Nagłówek trzeciego poziomu, np. podsekcja pod h2.

```html
<h3>Rowery miejskie</h3>
```

### h4

Uzupełnienie. Nagłówek czwartego poziomu.

```html
<h4>Modele dziecięce</h4>
```

### h5

Uzupełnienie. Nagłówek piątego poziomu.

```html
<h5>Rozmiary kół</h5>
```

### h6

Uzupełnienie. Nagłówek szóstego poziomu.

```html
<h6>Uwagi do rozmiaru</h6>
```

### p

Priorytet egzaminacyjny. Oznacza akapit tekstu. Listy i tabele umieszczaj poza akapitem.

```html
<p>Zadzwoń, aby zarezerwować rower.</p>
```

### span

Priorytet egzaminacyjny. Neutralne grupowanie fragmentu wiersza, np. do wyróżnienia ceny CSS-em.

```html
<span class="cena">49 zł</span>
```

### a

Priorytet egzaminacyjny. Tworzy odnośnik, gdy ma href. Zapis #id przenosi do elementu o tym identyfikatorze.

```html
<a href="oferta.html">Zobacz ofertę</a>
```

### strong

Priorytet egzaminacyjny. Oznacza ważną lub pilną treść.

```html
<strong>Rezerwacja jest wymagana.</strong>
```

### em

Priorytet egzaminacyjny. Kładzie nacisk znaczeniowy na fragment zdania.

```html
<em>Każdy</em> rower ma zapięcie.
```

### b

Uzupełnienie. Zwraca uwagę na wyraz bez oznaczania większej ważności.

```html
Tryb <b>Standard</b>
```

### i

Uzupełnienie. Wyróżnia np. termin obcojęzyczny lub odmienny głos w tekście.

```html
<i lang="en">fallback</i>
```

### u

Rozpoznaj w dokumentacji. Oznacza tekst z nietekstową adnotacją, np. błąd pisowni.

```html
<u>progamista</u>
```

### s

Uzupełnienie. Oznacza informację, która straciła aktualność.

```html
<s>59 zł</s> 49 zł
```

### small

Uzupełnienie. Drobny druk, uwaga poboczna lub informacja prawna.

```html
<small>Cena za godzinę.</small>
```

### mark

Uzupełnienie. Oznacza fragment istotny w danym kontekście, np. trafienie wyszukiwarki.

```html
Rower <mark>miejski</mark>
```

### abbr

Uzupełnienie. Oznacza skrót. Atrybut title może podać rozwinięcie.

```html
<abbr title="HyperText Markup Language">HTML</abbr>
```

### dfn

Rozpoznaj w dokumentacji. Oznacza wystąpienie terminu definiowanego w otaczającej treści.

```html
<p><dfn>DOM</dfn> to model dokumentu.</p>
```

### cite

Uzupełnienie. Oznacza tytuł cytowanego lub przywoływanego dzieła.

```html
<cite>Informator CKE</cite>
```

### q

Uzupełnienie. Krótki cytat wewnątrz akapitu.

```html
<p>Polecenie brzmi: <q>utwórz listę</q>.</p>
```

### blockquote

Uzupełnienie. Wydzielony blok cytatu.

```html
<blockquote><p>Treść cytatu.</p></blockquote>
```

### code

Priorytet egzaminacyjny. Oznacza kod lub jego fragment.

```html
Użyj <code>COUNT(*)</code>.
```

### pre

Priorytet egzaminacyjny. Wyświetla tekst z zachowaniem wcięć i nowych wierszy. Często opakowuje code.

```html
<pre><code>const x = 1;</code></pre>
```

### kbd

Uzupełnienie. Opisuje dane wprowadzane przez użytkownika, np. klawisze.

```html
Naciśnij <kbd>Enter</kbd>.
```

### samp

Rozpoznaj w dokumentacji. Oznacza przykładowy wynik działania programu.

```html
<samp>Import zakończony</samp>
```

### var

Rozpoznaj w dokumentacji. Oznacza zmienną lub wielkość matematyczną.

```html
<var>n</var> oznacza liczbę sztuk.
```

### sub

Uzupełnienie. Indeks dolny.

```html
H<sub>2</sub>O
```

### sup

Uzupełnienie. Indeks górny.

```html
m<sup>2</sup>
```

### br

Priorytet egzaminacyjny. Wstawia twarde łamanie wiersza, np. w adresie.

```html
ul. Zielona 5<br>00-001 Warszawa
```

### wbr

Rozpoznaj w dokumentacji. Wskazuje dopuszczalne miejsce łamania bardzo długiego wyrazu.

```html
bardzo<wbr>długie<wbr>słowo
```

### hr

Uzupełnienie. Oznacza tematyczne przejście pomiędzy fragmentami treści.

```html
<p>Część pierwsza</p><hr><p>Część druga</p>
```

### time

Uzupełnienie. Reprezentuje datę, godzinę lub czas trwania w formie czytelnej maszynowo.

```html
<time datetime="2026-11-21">21 listopada</time>
```

### data

Rozpoznaj w dokumentacji. Łączy czytelny tekst z wartością dla oprogramowania. Dla dat służy time.

```html
<data value="42">Rower miejski</data>
```

### ins

Uzupełnienie. Oznacza dodany fragment dokumentu.

```html
<ins>Nowy punkt regulaminu</ins>
```

### del

Uzupełnienie. Oznacza usunięty fragment dokumentu.

```html
<del>Poprzedni punkt regulaminu</del>
```

### bdi

Rozpoznaj w dokumentacji. Izoluje kierunek pisma w tekście, np. w nieznanej nazwie użytkownika.

```html
Użytkownik <bdi>علي</bdi>
```

### bdo

Rozpoznaj w dokumentacji. Wymusza kierunek tekstu podany w dir.

```html
<bdo dir="rtl">ABC</bdo>
```

### ruby

Rozpoznaj w dokumentacji. Łączy tekst bazowy z adnotacją wymowy, np. w języku japońskim.

```html
<ruby>日<rt>にち</rt></ruby>
```

### rt

Rozpoznaj w dokumentacji. Treść adnotacji wymowy w ruby.

```html
<ruby>日<rt>にち</rt></ruby>
```

### rp

Rozpoznaj w dokumentacji. Nawias zastępczy dla przeglądarek bez renderowania adnotacji ruby.

```html
<ruby>日<rp>(</rp><rt>にち</rt><rp>)</rp></ruby>
```

## Listy

### ul

Priorytet egzaminacyjny. Lista nieuporządkowana, której pozycjami są elementy li.

```html
<ul><li>HTML</li><li>SQL</li></ul>
```

### ol

Priorytet egzaminacyjny. Lista uporządkowana, np. kolejność kroków.

```html
<ol><li>Importuj</li><li>Uruchom</li></ol>
```

### li

Priorytet egzaminacyjny. Pozycja listy ul, ol lub menu.

```html
<ol><li>Pierwszy krok</li></ol>
```

### dl

Uzupełnienie. Lista grup nazw i opisów, np. słownik.

```html
<dl><dt>DOM</dt><dd>Model dokumentu</dd></dl>
```

### dt

Uzupełnienie. Nazwa lub termin w grupie listy dl.

```html
<dl><dt>PHP</dt><dd>Język skryptowy</dd></dl>
```

### dd

Uzupełnienie. Opis lub wartość przypisana do terminu w dl.

```html
<dl><dt>Rozmiar</dt><dd>600 × 400 px</dd></dl>
```

### menu

Rozpoznaj w dokumentacji. Lista poleceń, strukturalnie podobna do ul.

```html
<menu><li><button type="button">Usuń</button></li></menu>
```

## Tabele

### table

Priorytet egzaminacyjny. Tworzy tabelę danych uporządkowanych w wiersze i kolumny.

```html
<table><tr><td>Rower</td><td>10 zł</td></tr></table>
```

### caption

Priorytet egzaminacyjny. Podpis lub tytuł tabeli, umieszczany przed wierszami i grupami kolumn.

```html
<table><caption>Cennik</caption><tr><td>10 zł</td></tr></table>
```

### thead

Priorytet egzaminacyjny. Grupuje wiersze nagłówkowe tabeli.

```html
<thead><tr><th scope="col">Cena</th></tr></thead>
```

### tbody

Priorytet egzaminacyjny. Grupuje zwykłe wiersze danych.

```html
<tbody><tr><td>10 zł</td></tr></tbody>
```

### tfoot

Uzupełnienie. Grupuje wiersze stopki, np. podsumowanie.

```html
<tfoot><tr><td>Suma: 30 zł</td></tr></tfoot>
```

### tr

Priorytet egzaminacyjny. Wiersz tabeli z komórkami th lub td.

```html
<tr><th scope="row">Sobota</th><td>10:00</td></tr>
```

### th

Priorytet egzaminacyjny. Komórka nagłówkowa. scope wskazuje wiersz lub kolumnę, której dotyczy.

```html
<th scope="col">Cena</th>
```

### td

Priorytet egzaminacyjny. Komórka danych. colspan i rowspan rozciągają ją na kilka kolumn lub wierszy.

```html
<td colspan="2">Brak rezerwacji</td>
```

### colgroup

Uzupełnienie. Grupuje kolumny tabeli, np. do przypisania klasy.

```html
<colgroup class="ceny" span="2"></colgroup>
```

### col

Uzupełnienie. Reprezentuje co najmniej jedną kolumnę wewnątrz colgroup.

```html
<colgroup><col class="cena"></colgroup>
```

## Formularze

### form

Priorytet egzaminacyjny. Grupuje kontrolki i określa adres action oraz metodę method przesłania danych.

```html
<form action="zapis.php" method="post">…</form>
```

### label

Priorytet egzaminacyjny. Etykieta kontrolki. Dopasuj for do id kontrolki lub zagnieźdź ją w etykiecie.

```html
<label for="km">Dystans</label><input id="km" name="km">
```

### input

Priorytet egzaminacyjny. Pole formularza zależne od type. name określa nazwę wysyłanego pola.

```html
<input type="number" name="sztuki" min="1" required>
```

### textarea

Priorytet egzaminacyjny. Pole tekstowe na kilka wierszy. Początkowa wartość znajduje się między znacznikami.

```html
<textarea name="uwagi" rows="4">Bez uwag</textarea>
```

### button

Priorytet egzaminacyjny. Przycisk. W formularzu podaj type="button" dla akcji JS lub type="submit" dla wysyłki.

```html
<button type="submit">Zapisz</button>
```

### select

Priorytet egzaminacyjny. Lista wyboru. Atrybut multiple pozwala wybrać kilka opcji.

```html
<select name="typ"><option value="1">Miejski</option></select>
```

### option

Priorytet egzaminacyjny. Pozycja select, optgroup albo datalist. value określa wartość kontrolki.

```html
<option value="2" selected>Górski</option>
```

### optgroup

Uzupełnienie. Grupuje opcje w select i nadaje grupie etykietę.

```html
<optgroup label="Sport"><option>Szosa</option></optgroup>
```

### datalist

Uzupełnienie. Lista podpowiedzi połączona z input przez list i id. Sama nie ogranicza wpisywanych wartości.

```html
<input list="miasta"><datalist id="miasta"><option value="Łódź"></datalist>
```

### fieldset

Uzupełnienie. Grupuje semantycznie powiązane kontrolki. Nagłówek grupy daje legend.

```html
<fieldset><legend>Dane</legend><label>Imię <input name="imie"></label></fieldset>
```

### legend

Uzupełnienie. Opis grupy kontrolek, zwykle pierwszy element fieldset.

```html
<fieldset><legend>Rodzaj biletu</legend>…</fieldset>
```

### output

Uzupełnienie. Wyświetla wynik obliczeń lub akcji użytkownika.

```html
<output id="suma" for="cena liczba">0 zł</output>
```

### progress

Uzupełnienie. Pokazuje postęp działania. Bez value pokazuje postęp o nieokreślonej wartości.

```html
<progress value="3" max="10">3/10</progress>
```

### meter

Uzupełnienie. Pokazuje pomiar w znanym zakresie, np. ocenę lub temperaturę.

```html
<meter min="0" max="10" value="7">7/10</meter>
```

### selectedcontent

Rozpoznaj w dokumentacji. W mechanizmie konfigurowalnego select pokazuje kopię treści aktualnie wybranej opcji.

```html
<select><button><selectedcontent></selectedcontent></button><option>Miejski</option></select>
```

## Media

### img

Priorytet egzaminacyjny. Osadza obraz. src wskazuje plik, alt niesie treść alternatywną lub jest pusty dla dekoracji.

```html
<img src="rower.jpg" alt="Czerwony rower przy wejściu">
```

### figure

Uzupełnienie. Reprezentuje samodzielną ilustrację lub przykład, opcjonalnie z podpisem.

```html
<figure><img src="mapa.png" alt="Trasa do parku"><figcaption>Trasa A</figcaption></figure>
```

### figcaption

Uzupełnienie. Podpis figure. Umieść go jako pierwszy albo ostatni element figury.

```html
<figcaption>Widok trasy z południa</figcaption>
```

### picture

Uzupełnienie. Wybiera źródło obrazu na podstawie warunków. Zawiera img jako element docelowy i zapasowy.

```html
<picture><source type="image/webp" srcset="rower.webp"><img src="rower.jpg" alt="Rower"></picture>
```

### source

Uzupełnienie. Wskazuje alternatywne źródło w picture, audio lub video.

```html
<source media="(max-width: 600px)" srcset="male.jpg">
```

### audio

Uzupełnienie. Osadza materiał dźwiękowy. controls wyświetla sterowanie.

```html
<audio controls src="opis.ogg"></audio>
```

### video

Uzupełnienie. Osadza film z możliwością sterowania i podania grafiki poster.

```html
<video controls src="trasa.mp4" poster="kadr.jpg"></video>
```

### track

Uzupełnienie. Dodaje ścieżkę tekstową, np. napisy WebVTT w video.

```html
<track kind="captions" src="napisy.vtt" srclang="pl" label="Polskie">
```

### map

Rozpoznaj w dokumentacji. Definiuje mapę obszarów obrazu połączoną z img przez usemap.

```html
<map name="plan"><area shape="rect" coords="0,0,80,80" href="wejscie.html" alt="Wejście"></map>
```

### area

Rozpoznaj w dokumentacji. Definiuje klikalny obszar mapy obrazu. Kształt i współrzędne podają shape i coords.

```html
<area shape="circle" coords="40,40,18" href="most.html" alt="Most">
```

### iframe

Uzupełnienie. Osadza osobny dokument. Atrybut title opisuje zawartość ramki.

```html
<iframe src="cennik.html" title="Cennik wypożyczalni"></iframe>
```

### canvas

Uzupełnienie. Udostępnia płótno pikselowe do rysowania przez skrypt.

```html
<canvas id="wykres" width="300" height="150">Wykres</canvas>
```

### embed

Rozpoznaj w dokumentacji. Osadza zewnętrzny zasób obsługiwany przez przeglądarkę, np. PDF.

```html
<embed type="application/pdf" src="plan.pdf">
```

### object

Rozpoznaj w dokumentacji. Osadza zasób i może wyświetlić HTML zastępczy.

```html
<object data="plan.pdf" type="application/pdf"><a href="plan.pdf">Pobierz plan</a></object>
```

## Interakcje

### details

Uzupełnienie. Natywna rozwijana sekcja. Może działać bez JavaScriptu.

```html
<details><summary>Rozwiązanie</summary>Treść rozwiązania</details>
```

### summary

Uzupełnienie. Etykieta rozwijanej sekcji details.

```html
<details><summary>Podpowiedź</summary>Użyj JOIN.</details>
```

### dialog

Rozpoznaj w dokumentacji. Okno dialogowe. Metoda showModal() otwiera je w trybie modalnym.

```html
<dialog id="pomoc"><p>Instrukcja</p></dialog>
```

### template

Rozpoznaj w dokumentacji. Przechowuje niewyświetlany fragment dokumentu przeznaczony zwykle do klonowania przez JS.

```html
<template id="wiersz"><li></li></template>
```

### slot

Rozpoznaj w dokumentacji. Punkt podstawiania treści w drzewie Shadow DOM komponentu.

```html
<slot name="tytul">Tytuł domyślny</slot>
```

## Osadzane standardy

### svg

Uzupełnienie. Korzeń osadzonej grafiki wektorowej SVG.

```html
<svg viewBox="0 0 20 20"><circle cx="10" cy="10" r="8"/></svg>
```

### math

Rozpoznaj w dokumentacji. Korzeń zapisu matematycznego MathML.

```html
<math><msup><mi>x</mi><mn>2</mn></msup></math>
```

## Starsze elementy spotykane w historycznych przykładach

font i center zastąp stylami CSS. big i tt zastąp typografią CSS, a dla fragmentów kodu wybierz także element code. frame i frameset służyły do dzielenia okna na ramki. Do współczesnego układu strony użyj CSS. marquee i blink odpowiadały za dekoracyjny ruch lub miganie. [Funkcje przestarzałe WHATWG](https://html.spec.whatwg.org/multipage/obsolete.html)
